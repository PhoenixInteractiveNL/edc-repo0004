
The programs presented in this directory were
written or edited by talented and dedicated
programmer Jim Gerrie.

This emulator archive has unbundled the programs
from some of their documentation, ancillary files,
file listings, and WAVs.  If you're looking for
those, download the originals at


http://www3.ns.sympatico.ca/jimgerrie/jsoft.html
Jim Gerrie's MC10 website


Monster2.c10 - game
	CLOAD and RUN
	Maze puzzle game
	Welcome to the Monster's Lair
	by Charlie Gerrie
	For every move you make the
	monster moves twice.  It always
	prefers to move left and right.
	Use the arrow keys WASZ to move your
	adventurer.  Press R to reset a lair.
	Press SPACE to skip your move.
	Press L to leave (which exits the program).
	Avoid the monster and exit the lair.
	There are 10 lairs to complete.
	Good luck.
	Note:  This changes the graphics mode to ASG6.  If you BREAK,
	you will need to hard reset.
