If you're using Notepad, turn on wordwrap.


These .C10 files are MC-10-format cassette files.

To use them, type CLOAD on VMC-10, and press RETURN when prompted to do so.

From the File menu, select Play Cassette File, and choose the .C10 file you want.

NOTE:  Some of these files have been separated from their information and other useful files.  If you're interested in finding out more about a particular file, go see its "downloaded from" website!

====
argo.c10 - game
	BASIC, CLOAD and RUN
	Make as many words as possible from the letters in the shortest time
	http://users.bigpond.net.au/jagf/mc10.html

assemble.c10
	downloaded from	http://users.bigpond.net.au/jagf/mc10.html

autorun.C10 - util
	by G. Pollock
	see autorun_README.txt
	downloaded from	http://users.bigpond.net.au/jagf/mc10.html

backup.c10 - util
	BACKUP by Gary Furr
	Used to BACKUP programs.
	Program appeared in Softgold Australian CoCo magazine
	 in 1987 (magazine wasn�t dated)
	Usage:
		EXEC. Press any key to start program. 
		Load the program to be copied. 
		When SAVING appears press any key to CSAVE.
	The program will copy both BASIC and M.L.
	Programs won�t overwrite BACKUP, as it is located below BASIC.
	EXEC address 17090
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

basketba.c10
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

catch.c10
--BASIC, CLOAD and RUN
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

Clock.c10 - util
	by G.Furr
	--ML CLOADM EXEC
	Puts a clock in the upper right corner of the screen
	+16K RAM required
	Demonstration of count/compare timed interrupt
	http://users.bigpond.net.au/jagf/mc10.html

decode.c10
	downloaded from
	http://users.bigpond.net.au/jagf/mc10.html

disass1.c10 - util
	disassemble a memory-resident ML program
	downloaded from	http://users.bigpond.net.au/jagf/mc10.html

disass2.c10 - util
	ML util, disassemble, view memory, execute.
	downloaded from	http://users.bigpond.net.au/jagf/mc10.html

ducshoot.c10
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

frogger.c10
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

gap.c10
	GAP - Generic Accounting Program
	Larry Allen - 80's
	--BASIC, CLOAD and RUN
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

grloop.c10
displays all the various MC10 graphics modes,
except Sg6 (curious, huh?)
By James the Animal Tamer

groan.c10
dice gane.  BASIC.  Load and run.
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

hangman.c10
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

hb4400.c10
hb7500.c10
hb4500.c10
HUMBUG ASSEMBLE/DISSASSEMBLE
FILE: MACHINE LANGUAGE
Three versions are included:
HB4400 - $4400 to $4eff
HB4500 - $4500 to $4fff
HB7500 - $7500 to $7fff
downloaded from
http://users.bigpond.net.au/jagf/mc10.html
--
HUMBUG 2672 bytes -------------------------  space for user ML
HB4400 -- $4400 (17408) to $4eff (4e70) ---  43500-43ff, 4f00-4fff, 5000-7fff
HB4500 -- $4500 (17664) to $4fff (4f70) ---  43500-44ff, 5000-7fff
HB7500 -- $7500 (29952) to $7fff (7f70) ---  4350-6fff
--
AD - ASCII Dump (look for text strings)
AI - ASCII Input (direct input of ASCII data) (Shift @/BREAK to return)
AO - ASCII Output (output to screen)
AT - Analyze Tape (gives start, end, exec address)
BA - change BAud rate (of i/o port)
BP - print BreakPoints
BR - BReakpoint set/reset (4 bps in ML program)
CO - COntinue after breakpoint (cancel BR first)
CS - CheckSum (16-bit checksum of locations)
DE - Disassemble
EX - EXit (return to BASIC)
FI - FInd (find 1, 2, or 3 byte numbers; 2, 4, or 6 hex digits; gives some bytes before and after)
FM - Fill Memory (fill memory with specified byte)
HD - Hex Dump (8 bytes per line)
HE - HElp (list commands)
JU - JUmp (jump to program)
MC - Memory Compare (compare two memory areas)
ME - Memory Examine/change (1. Enter new value;  2. Up Arrow to back up;  3. Down Arrow to move on;  4. ENTER to return)
MM - Move Memory (block move of memory)
MT - Memory Test (looks for bad bits)
RC - Register Change (C - condition code;  A or B - accumulators;  X - index register;  P - program counter;  into 'ME' mode)
RE - Register Examine (print all register contents)
SA - SAve to cassette (CSAVEM)
SS - Single Step (move one step at a time after breakpoint)
ST - STart single step (if no breakpoint)
!! - monitor reset (like power up)
SHIFT @ followed by BREAK - cancel current command
SHIFT @ followed by O - turn i/o port on and off (printing)
SHIFT @ followed by P - pause mode (on and off)


hires.c10
	Must be used with rom1_3.c10
	HIRES DRAWING by Graham Pollock
	Black and white graphics tablet.
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

hirescol.c10
	Must be used with rom1_3.c10
	HIRES DRAWING by Graham Pollock
	See hirescol_README.txt
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

id_csave.c10 - util
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

io_rec.c10 - util
	Recover a partial program from a tape that has an IO error.
	Run it, then CLOAD your bad tape.
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

kaleido.c10 - demo
	From the manual that came with your MC-10.
	You do have an MC-10, don't you?

kaleidoa.c10 - demo
	From the manual that came with your MC-10.
	You do have an MC-10, don't you?

leapfrog.c10 - game
	Move red and blue blocks from one side to the other
	in as few moves as possible
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

llist.c10 - util
	Line list by G.Furr
	The program was written in 1986.
	Once executed prints all the line numbers in your
	basic listing, allowing you to check if you have missed
	entering any line numbers.
	How to run:
		After the program has been run, enter NEW. 
		Then CLOAD your basic program.
		EXEC 32000
		LIST your program and use the <SHIFT> + <@>
		keys to pause the listing.
		You can tap the <ENTER> key to continue listing
	To do:
	To display the line numbers vertically.
	Include Machine Language LLISTing in archive.
	users.bigpond.net.au/jagf/mc10.html

masterm.c10 - game
	Really nice game of Mastermind!
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

Mcos.c10
	ML mini-monitor.  Don't know how to use it or anything else.
	MJBauer 1984
	CLOADM and EXEC.
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

mcword.c10
	MCWORD by Robert Schecter
	CLOADM:EXEC
	A word processor.  Don't type too fast.
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

milo.c10
	--BASIC, CLOAD and RUN
	math for kids
	downloaded from	http://users.bigpond.net.au/jagf/mc10.html

mmania.c10 - game
	MICOMANIA - Darren Ottery
	MC-10 with 16K expander
	This game is similar to PAC-MAN.  
	You are yellow and the ghost is red.
	You can't eat the ghost at any time during the game.
	Eat as many dots as possible before the ghost eats you
	or your time runs out. If your score reaches 4500,
	then you get an extra 100 units added to your time.
	The ghost leaves a trail of dots wherever he
	goes so you won't run out. Use WASZ to move.
	downloaded from	users.bigpond.net.au/jagf/mc10.html

morse.c10
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

numbers.c10 - educational
	What number comes after 6?
	Then it draws a face.
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

pagelist.c10
PAGELIST by G.POLLOCK.  PAGELIST is a machine language that will allow you to LIST your BASIC one screen (page) at a time. The BASIC LISTing actually scrolls up 12 lines at a time so that the bottom lines of one page will become the top lines of the next.
When you RUN PAGELIST, you can choose in which part of the memory you want it to reside: - either at the top of RAM or below another M.L program, such as little-e.
After that, any BASIC program in the computer can be LISTed a page at a time. Pressing the space bar will move you onto the next page. Holding down the space bar will give continous LISTing as normal.
If you want to stop on a certain page then just press BREAK.
If you want to alter the page length, then you can adjust the number in line 180 before you CSAVE the BASIC loader. I find 12 convenient.
This program appeared in the MC-10 Users Group magazine March 1986.
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

pontoon.c10
downloaded from
http://users.bigpond.net.au/jagf/mc10.html


rom1_3.c10
See hires.c10
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

sg6bom.c10
Semigraphics 6 game by G.Pollock, MC-10 Users Group March 1986
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

skills.c10 - game
	typing skills, type the letters
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

sound.c10 - demo
	Plays several different sound effects.
	By Gary Furr (author of Extended BASIC)
	http://users.bigpond.net.au/jagf/mc10.html

speech.c10 - util
	NOTE:  you'll need to use "+40K (homebrew)" under configure... memory... 
	-	to use this program with the emulator.  Either that, or you'll have
	-	to figure out how to reset the top-of-memory pointer to somewhere
	-	below where this ML program resides.
	SPEECH by G.Furr 80's
	Phonetic speech synthesiser, uses the C64
	voice synthesiser for the base phonetics behind the application.
	Syntax: Say "yryryr"
	Examples:
	BBBBOY = BOY
	CHAERRYY = CHERRY
	"OY VVEY"
	Use the following phonetics to create words.
	YR, OW, ER, CH, WH, WW, LL, NG, ZZ, ZH, SH,
	VV, GG, AW, UH, BB, AE, YY, AA, AO, UW, DD,
	EY, LY, DH, MM, AX, RR, TT, IH, NN, JJ, PP,
	KK, EH, OY, AY
	Filetype: ML, CLOADM and EXEC
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

speed.c10 - util
	by G.POLLOCK
	Slows down the display of text to the screen.
	This program appeared in the MC-10 Users Group magazine February 1986.
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

spellit.c10 - game
	by G.Pollock
	Spell the words spelling/memory drill
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

squares.c10 - demo
	From TRS-80 Color Computer Programs
	page 224
	(C) 1981 Tom Rugg and Phil Feldman

tables.C10 - game
	by G.Pollock
	Drill your multiplication table
	Appeared Australian MiCo July 1985
	If you want to drill on a new set of tables
	then you will need to BREAK and RUN.
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

tpindex.c10
TAPE INDEX by Graham Pollock
Appeared in Australian CoCo September 1985
	Tape Index is a program that will allow you to scan through a tape and find out about the programs on it.  To do this it will SKIPF through the tape and look at some storage addresses in RAM after each program has gone past.
	The program filename is stored between addresses 16991 ($425F) and 16998 ($4266).  The program type is stored at address 16999 ($4267).  The 3 types of programs are identified by their own file type number.-
             0 means BASIC
             2 means MACHINE LANGUAGE
             4 means NUMERICAL ARRAY
	The addresses 17004($426c) and 17005 ($426d) hold the program length for BASIC and array types, and the start address for M.L. programs. If you have a printer you may choose to have a hard copy of your tape index. There is only one problem. It won't give you the length of BASIC programs on MICOOZ (but it will TOM LEHANES tapes CSAVED with the MC-10 emulator, COCO-MICO).
	EMULTATOR NOTE:  For Virtual MC-10, this might be useful for WAV files.  C10 files can contain only one tape file image anyway :-)
downloaded from
http://users.bigpond.net.au/jagf/mc10.html

tune.c10 - demo
	song player program, slightly out of tune
	by Gary Furr (?)
	downloaded from http://users.bigpond.net.au/jagf/mc10.html

walloons.c10 - demo
	Watch the music video.  LOL.
	downloaded from http://users.bigpond.net.au/jagf/mc10.html
