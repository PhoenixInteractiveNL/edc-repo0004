Here are some machine language programs I wrote for
the MC-10.  

To load them into the Virtual MC-10, type CLOADM, then play the corresponding .c10 file (under File->Play Cassette file).
Type "EXEC" to run them unless otherwise noted.

To convert them to wave files you can play on a real MC-10 use the "C10TOWAV.exe" file that's bundled in the tools directory of the Virtual MC-10.  Once you've got a .wav file you can play it directly into your MC-10 by hooking up the headphone jack of your computer to the MC-10.  

- BubbleSort.c10
- QuickSort.c10

Sorts the screen in ascending/descending order via bubble/quicksort algorithms.  The QuickSort performs the sorting in-place.

- Kaleidoscope.c10

Similar to the SPARKLE program -- but using the color graphics 3 mode.

- LPrintPi.c10

Prints my favorite mathematical constant to the printer.
type EXEC:100 to print out 100 decimal places.  

It computes it by the formula:
  Pi/4 = 6 arctan(1/8) + 2 arctan(1/57) + arctan(1/239)

- Pac-Man.c10

A squished version of PAC-MAN that uses a color graphics
mode.  

- ReverseVideo.c10

Puts the MC-10 into reverse video.  You can CLOAD or quicktype other programs and it will still put things in reverse video.

- Tetris.c10 and Tetris4K.c10

These were an attempt at "Obnoxious Tetris" which I played
in college.  Truly obnoxious.  Too irritating to play.  :)
Tetris4K will fit on an MC-10 without the expansion unit.

- RG2LIFE.c10

A resolution graphics mode of Conway's Life.  It starts with the R pentomino.  

