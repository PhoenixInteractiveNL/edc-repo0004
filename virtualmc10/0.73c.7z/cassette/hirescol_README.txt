HI-RES COLOURING by GRAHAME POLLOCK
Appeared in Australian MiCo December 1985 P48
--------------------------------------------------------------
File: Basic
Requirement ROM1.3

HIGH-RES COLORING is a drawing program which works in the 4-color graphics modes on the MC-10.

You must he in ROM1.3 in order for this program to work.

You can choose from 6 screens:-
   SCRN POKE  PIXELS  GRID    BYTES
    1   36    12288   128X96  3072
    2   40    8192    128X64  2048
    3   44    24576   128X192 4096
    4   100   12288   128X96  3072
    5   104   8192    128X64  2048
    6   108   24576   128X192 4096

Column1(SCRN) is the number you need to press to get that graphics screen.  The POKE column tells you the number you need to POKE into the ROM1.1 SOUND routine (36782) so that the graphics screen is invoked when a sound is called.

The third  and fourth columns tell you the number and arrangement of pixel's on the screen. The last column tells you the number of bytes of memory used by each screen.

Each screen has 32 bytes across(each of 4 pixel's) and the length  of the screen varies. Screens 3 and 6 take up 4K bytes of memory but display 6K( 4K with the first 2K repeated on the bottom).

There is another 4-color mode but it is 64X64 with 16 bytes across so I haven't included it here.

There are also a corresponding number of 2-color modes which were the subject of another article.

On each screen there is one background colour and 3 drawing colours but some are a bit difficult to
distinguish on a B&W TV.  You change your drawing colour by pressing the numbers 7, 8 or 9 (for colours 1,2 and 3)

Hold down the arrow keys to draw. You can draw a diagonal line by holding down 2 keys at once.

To go into rubout just press the space bar.  You can only rub out one colour at a time but you can change the rubout colour by pressing 7,8 or 9. Press the space bar again and you go back into drawing mode.

To save your drawing start recording and press 'TS'. Pressing 'C' will -clear the screen, and pressing 'TL' and PLAYing the tape will load in your drawing.  In this way you ran work on a drawing in stages.

To return to ROMI.1 command mode, you should press 'R'. If you forget and press 'BREAK', you must POKE36782,0:SOUND1,1 without looking at the screen (you won't be able to read it anyway!)

In the 4-color modes there are 2 bits for each colour.
They are.-
BACKGROUND=00
 COLOR l(7)=01
 COLOR 2(8)=10
 COLOR 3(9)=11

Each byte consists of 8 bits so that it controls 4 pixel's.   If a byte contains the number 45 (001011101) then the left pixel is the background colour. The next pixel to the right is colour 2. The next pixel is colour 3 and the last one is colour 1.

Now that  you've been given the high resolution tools to work with, it's over to you.

