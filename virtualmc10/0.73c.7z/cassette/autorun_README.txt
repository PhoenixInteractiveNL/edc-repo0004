AUTORUN by Grahame Pollock
Appeared in MCUG Newsletter (date unknown)
------------------------------------------

It might seem a bit lazy but it is different. A while ago I thought to myself, "why should I have to type in RUN after a program is CLOADed in?
Why can't it start itself running?

Well with AUTORUN, it will. You CLOAD "AUTORUN" and RUN it. Answering the prompts, you can decide where you would like the AUTORUN machine code to be placed.
After that, any BASIC program that you CLOAD in will automatically begin running.
For those of you who would like to see the code, it goes like this:-

42A9	JMP XXXX	7E XXXX 	JUMP FROM KEYBOARD SCAN

XXXX	PSH A		36		PUSH A ONTO THE STACK
	LDA A #$97	86 97		LOAD A WITH CLOAD
	CMP A $42B2	B1 42B2	IS "CLOAD" IN COMMAND?
	BEQ ARUN	27 02		BRANCH TO START AUTORUN
	PUL A		32		PULL A OFF THE STACK
	RTS		39		RETURN
ARUN  LDD #$8E55	CC 8E55	LOAD D WITH RUN TOKEN
	STD $42B2	FD 42B2   	STORE IN COMMAND LINE
	LDD #$4E00	CC 4E00	LOAD REST OF RUN
	STD  $42B4	FD 42B4	STORE IT
	LDAA #$00	86 00		LOAD A WITH ZERO
	STA A $42B6	B7 42B6	STORE IT
	LDX  #$4348	CE 4348	POINT X TO BASIC LINE #1
	LDD 00,X	EC 00		LOAD D WITH FIRST LINE #
	STD $A5	DD A5		STORE D IN $00A5
	JSR  $E3D9	BD E3D9	START
	JSR  $E61D	BD E61D	PROGRAM
	JMP $E519	7E E519	RUNNING

