Defend, a TRS-80 MC-10 game.

Object: 

Block the object moving towards the top of the screen.
If you miss, the object will stay at the top of the screen.
If the top of the screen gets full all the way across your game
is over. Also, if you miss 3 objects in a row your game will be over.

Controls:

Use "1" to move left
use "-" to move right

Score:

100 points per object blocked.
-100 points per object missed.

In the ZIP [unzipped in emulator archive]:

This readme file [you're reading it now].
Defend.wav to record to tape and load on your MC-10 [left out of emulator archive]!!
Defend.c10 for use with the emulator Virtual MC-10.
Defend.txt a list of the program. Can also be used with the quick type
feature of Virtual MC-10 [left out of emulator archive].

Links:

Yahoo MC-10 group: http://groups.yahoo.com/group/trs80mc10club/
Virtual MC-10: http://www.geocities.com/emucompboy/

4/29/04 chazbeenhad@hotmail.com
