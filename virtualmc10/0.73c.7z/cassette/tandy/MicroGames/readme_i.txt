If you're reading this with Notepad, set word wrap to "on."


Quick instructions for MicroGames:

These games are cassette files.  CLOAD them, and then RUN.
To play, you will need to set the emulator to use the
"emulated" keyboard mode;  to do that, from the
Config menu select Keyboard.  This brings up the
keyboard configuration dialog box.  Check the "Emulated"
radio button, and click on "Okay."

(When you're done playing, you may want to set the
keyboard mode back to "sensible.")

==============

Most of these games will pause with SHIFT @ (in Emulated
keyboard mode, this is Shift [) and resume by pressing
any key.

PONG:  Player 1 uses W and Z to move his paddle up
and down.  Player 2 uses P and /.  To start a new
game, BREAK back to BASIC (emulator uses ESC key as
BREAK), and RUN again.

BREAKOUT:  Move the paddle up and down by pressing
the W and Z keys.

EGGS:  Use the A and S keys to move the egg catcher left
and right.  Shoot the pesky bird by pressing the SPACE
BAR.  To start a new game, BREAK back to BASIC (emulator
uses ESC key as BREAK), and RUN again.

LANDER:  The object of the game is to land with 0 velocity
at 0 altitude.  Press the number keys to fire your rocket;
higher number keys release more thrust.  To start a new
game, BREAK back to BASIC (emulator uses ESC key as BREAK),
and RUN again.

HORSE:  There's nothing you can do to make your horse win.
Sit back and enjoy the show.

========

Tape source - James
The digitizing process is never perfect.

Confidence: excellent -- the tape contains two images
of each game.  They matched.

Oddity: when CLOADed and then CSAVEd out again, the
resultant saved file is different from the original,
at offsets $91-92-93.  The image here reflects what's
on the tape, not what'd be CSAVEd.  *shrug*
