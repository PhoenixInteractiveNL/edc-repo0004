SUPER CLOAD by GRAHAM POLLOCK
Appeared in Australian MiCo September 1985 P54
----------------------------------------------
Look
Up in the sky!
It's a bird!
It's a plane!
No! It's SUPERCLOAD!
Faster than a speeding 1/0 ERROR
More powerful than an OM ERROR
Able to Cload tall Programs in a single key stroke.

SUPERCLOAD allows your MiCo to recover after a CLOADing error and CLOAD again, all by itself.  All you have to do is put in the initial CLOAD and press PLAY.  The first decent program will CLOAD in.  You can start CLOADing half way through a program and the following program will CLOAD in.

The machine language looks like this:-
429A 7E 4FF2 JMP    $4FF2
     -------------

4FF2 36       PSHA
put the A accumulator on the stack

4FF3 86 97    LDAA #$97
load the A accumulator with 197

4FF5 81 42B2 CMPA $42B2
compare A with the value at $4282

4FF8 27 02    BEG  $4FFC
branch to $4FFC if equal

4FFA 32       PULA
pull the A acc, off the stack

4FFB 39       RTS
return

4FFC 7E FD63 JMP   $FD63
jump to CLOAD

The BASIC loader is self-locating and You have a choice of two possible places:-
1. Below the top of RAM
2. Below last M.L. program

The second option actually loads the M.L. in below the DEFAULT EXECution address. It will only load in below previous M.L. if that M.L. has been EXECuted at it's start address.
In other words, SUPERCLOAD option2 will NOT interfere with either LITTLE-E or TRILIST. The MCIO has two error return extension   vectors. LITTLE-E uses the first at 17047-17049 ($4297-$4299) and SUPERCLOAD uses the second at 17050-17052 ($429A-$429C).

The listing:
      1 CLS:PRINT"SUPERCLOAD BY G.POLLOCK"
      2 GOT010
      3 FORSV=1T03:FORT=1TO3OOO:NEXTT:CSAVE"SUPCLOAD":PRINTSV:NEXTSV:END
      10 PRINT:PRINT"DO YOU WANT ME"
      30 PRINT:PRINT"1.  BELOW TOP RAM"
      40 PRINT:PRINT"2.  BELOW LAST M.L, PROGRAM"
      50 INPUTPN
      60 IFPN=1THENPK=16976:GOTO80
      70 PK=16927:GOTO95
      80 GOSUBlOO:CLEAR25,X
      85 PK=16976:GOSUB1OO
      90 GOT0110
      95 GOSUBlOO:CLEAR25,X:PK=16927:GOSUBlOO:GOTO110
      100 X=256*PEEK(PK)+PEEK(PK+1):X=X-14:RETURN
      110 FORZ=XTOX+12
      120 READA
      130 POKEZ,A:NEXTZ
      140 POKE17050@126
      150 POKE1705l,INT(X/256):POKE17052,X-INT(X/256)*256
      155 EXECX
      160 DATA 54,134,151,177,66,178,39,9,2
      170 DATA 50,57,126,253,99

