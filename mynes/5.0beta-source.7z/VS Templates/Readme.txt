Copy these files to:

C:\Users\<username>\Documents\Visual Studio 2012\My Exported Templates\

Run Visual Studio, in your project add new item and the templates will be listed in the add new item window.