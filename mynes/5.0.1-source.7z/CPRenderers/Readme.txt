﻿
Cross-Platform renderers. 
This library should includes renderers that can run on multi platforms (Windows, Linux, Mac OS X, ...etc)