﻿/* This file is part of My Nes
 * A Nintendo Entertainment System Emulator.
 *
 * Copyright © Ala Ibrahim Hadid 2009 - 2013
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
namespace MyNes
{
    partial class ISC_Player
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_up = new System.Windows.Forms.TextBox();
            this.textBox_left = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_right = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_down = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_select = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_start = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_b = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_a = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_turboB = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_turboA = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Up";
            // 
            // textBox_up
            // 
            this.textBox_up.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_up.Location = new System.Drawing.Point(45, 3);
            this.textBox_up.Name = "textBox_up";
            this.textBox_up.ReadOnly = true;
            this.textBox_up.Size = new System.Drawing.Size(250, 22);
            this.textBox_up.TabIndex = 1;
            this.textBox_up.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_up_KeyDown);
            this.textBox_up.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_up_MouseDoubleClick);
            // 
            // textBox_left
            // 
            this.textBox_left.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_left.Location = new System.Drawing.Point(45, 31);
            this.textBox_left.Name = "textBox_left";
            this.textBox_left.ReadOnly = true;
            this.textBox_left.Size = new System.Drawing.Size(250, 22);
            this.textBox_left.TabIndex = 2;
            this.textBox_left.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_left_KeyDown);
            this.textBox_left.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_left_MouseDoubleClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Left";
            // 
            // textBox_right
            // 
            this.textBox_right.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_right.Location = new System.Drawing.Point(45, 59);
            this.textBox_right.Name = "textBox_right";
            this.textBox_right.ReadOnly = true;
            this.textBox_right.Size = new System.Drawing.Size(250, 22);
            this.textBox_right.TabIndex = 4;
            this.textBox_right.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_right_KeyDown);
            this.textBox_right.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_right_MouseDoubleClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Right";
            // 
            // textBox_down
            // 
            this.textBox_down.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_down.Location = new System.Drawing.Point(45, 87);
            this.textBox_down.Name = "textBox_down";
            this.textBox_down.ReadOnly = true;
            this.textBox_down.Size = new System.Drawing.Size(250, 22);
            this.textBox_down.TabIndex = 6;
            this.textBox_down.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_down_KeyDown);
            this.textBox_down.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_down_MouseDoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Down";
            // 
            // textBox_select
            // 
            this.textBox_select.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_select.Location = new System.Drawing.Point(45, 227);
            this.textBox_select.Name = "textBox_select";
            this.textBox_select.ReadOnly = true;
            this.textBox_select.Size = new System.Drawing.Size(250, 22);
            this.textBox_select.TabIndex = 8;
            this.textBox_select.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_select_KeyDown);
            this.textBox_select.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_select_MouseDoubleClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Select";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 259);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Start";
            // 
            // textBox_start
            // 
            this.textBox_start.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_start.Location = new System.Drawing.Point(45, 255);
            this.textBox_start.Name = "textBox_start";
            this.textBox_start.ReadOnly = true;
            this.textBox_start.Size = new System.Drawing.Size(250, 22);
            this.textBox_start.TabIndex = 10;
            this.textBox_start.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_start_KeyDown);
            this.textBox_start.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_start_MouseDoubleClick);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 147);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "A";
            // 
            // textBox_b
            // 
            this.textBox_b.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_b.Location = new System.Drawing.Point(45, 115);
            this.textBox_b.Name = "textBox_b";
            this.textBox_b.ReadOnly = true;
            this.textBox_b.Size = new System.Drawing.Size(250, 22);
            this.textBox_b.TabIndex = 14;
            this.textBox_b.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_b_KeyDown);
            this.textBox_b.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_b_MouseDoubleClick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 119);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "B";
            // 
            // textBox_a
            // 
            this.textBox_a.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_a.Location = new System.Drawing.Point(45, 143);
            this.textBox_a.Name = "textBox_a";
            this.textBox_a.ReadOnly = true;
            this.textBox_a.Size = new System.Drawing.Size(250, 22);
            this.textBox_a.TabIndex = 12;
            this.textBox_a.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_a_KeyDown);
            this.textBox_a.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_a_MouseDoubleClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 203);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "TurboA";
            // 
            // textBox_turboB
            // 
            this.textBox_turboB.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_turboB.Location = new System.Drawing.Point(45, 171);
            this.textBox_turboB.Name = "textBox_turboB";
            this.textBox_turboB.ReadOnly = true;
            this.textBox_turboB.Size = new System.Drawing.Size(250, 22);
            this.textBox_turboB.TabIndex = 18;
            this.textBox_turboB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_turboB_KeyDown);
            this.textBox_turboB.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_turboB_MouseDoubleClick);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 175);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "TurboB";
            // 
            // textBox_turboA
            // 
            this.textBox_turboA.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_turboA.Location = new System.Drawing.Point(45, 199);
            this.textBox_turboA.Name = "textBox_turboA";
            this.textBox_turboA.ReadOnly = true;
            this.textBox_turboA.Size = new System.Drawing.Size(250, 22);
            this.textBox_turboA.TabIndex = 16;
            this.textBox_turboA.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_turboA_KeyDown);
            this.textBox_turboA.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox_turboA_MouseDoubleClick);
            // 
            // ISC_Player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox_turboB);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox_turboA);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox_b);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox_a);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_start);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_select);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_down);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_right);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_left);
            this.Controls.Add(this.textBox_up);
            this.Controls.Add(this.label1);
            this.Name = "ISC_Player";
            this.Size = new System.Drawing.Size(333, 296);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_up;
        private System.Windows.Forms.TextBox textBox_left;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_right;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_down;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_select;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_start;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_b;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_a;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_turboB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_turboA;
    }
}
