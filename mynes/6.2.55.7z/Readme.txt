My Nes
------
Copyright � Ala Ibrahim Hadid 2009 - 2015
E-mail: ahdsoftwares@hotmail.com


What is this ?
--------------
My Nes is A Nintendo Entertainment System / Family Computer (Nes/Famicom) emulator written in C#. 
My Nes is meant to be simple, powerful and accurate Nes emulator.

My Nes is open source .net freeware, licensed under the GNU GENERAL PUBLIC LICENSE; Version 3, 29 June 2007.

My Nes can pass all basic nes tests that test nes hardware behaviors, such as cpu 6502 instructions, 
ppu timing .... etc. However, My Nes pass most of these tests (known at development time of current version) 
without any kind of HACKING (changing some code to make a test pass), by emulating the exact hardware behavior.
For example, My Nes can pass cpu interrupt tests (cpu_interrupts_v2 by Shay Green <gblargg@gmail.com>) by 
emulating cpu cycle timing and interrupts check at the next half of cpu cycle. Same for DMA behavior, 
Sprite 0 Hit, Sprite overflow flags, APU length counter and IRQ ....etc

My Nes also implements the NTSC/PAL video generator (palettes), enjoy the nes real colors !

If you are looking for a simple Nes emulator provides accuracy that very close to the real hardware, 
My Nes is a one worth a try !

Also, compatibility is one of the key features, My Nes implements about 90% of documented boards and 
mappers which are needed to run more games. All mappers and boards included are implemented exactly as documented.

My Nes Interface Features
-------------------------
� Powerful Launcher that uses NesCart DB and SQLite databases to organize roms.
� Uses NesCart DB to show and use accurate game information.
. Ability to get and download game files and info directly from TheGamesDB.net into the Launcher.
� Ability to save snapshots of current game.
� Ability to record sound.
� Run game in windowed or fullscreen mode with useful video options like keep aspect ratio. 
� Support DirectInput (i.e. Joystick) and Xinput (i.e. XBox 360 controllers) for input mapping.
� Multilingual interface.
� Save and load state ability.

General Features:
-----------------
. Accuracy, My Nes pass almost all known nes tests by emulating the real hardware behaviors without any kind of emulation hack. 
� Compatibility, My Nes support more than 100 board/mapper which mean thousands of games are playable.
� Multithreaded Emulator, the emulation process run in thread separated from renderer threads. This may improve performance especially with multi core cpus.  

My Nes Emulation Specification
------------------------------
. CPU 6502: All CPU 6502 instructions implemented including the so called illegal opcodes.
. Interrupts: Implement exact interrupt timings like interrupt check before the last instruction behavior
. PPU: Implement the Picture Processor Unit as described in the wiki docs http://wiki.nesdev.com/w/index.php/PPU_rendering with exact timing
. Palettes: Implement the palette generator of NTSC video as described at http://wiki.nesdev.com/w/index.php/NTSC_video
. TV Formats: NTSC, PALB and DENDY.
. Sound: Implement all Nes 5 sound channels, MMC5 external sound channels and VRC6 external sound channels, along with sound downsampling using the Band-Limited Sound Buffer "Blip_Buffer" <http://www.slack.net/~ant/>.
. Sound Playback And Record: Fixed to 44100 Hz - 16 bit - Mono; Applied for playback and record. Sound record depends on emulation speed not on sound playback so record doesn't affected if the emulator run fast or slow.
. Mappers And Boards: Implement about 97% of known and documented mappers
. Controllers: 4 players joypads, Zapper and VSUnisystem DIP. Note that you'll need to connect Zapper or 4 Player in settings manually in order to use it

System Requirements
-------------------
. Works with Windows� XP SP3, Vista, Seven, 8 or 8.1, X86 or X64 bit.
. CPU: 2400 MHz or higher. Multicore CPU is recommended.
. RAM: 512 MB or higher.
. Microsoft .NET Framework 4.
. SlimDX Runtime .NET 4.0 x86 (January 2012) (Optional hence this release included in My Nes release package, install the run time if My Nes doesn't work)
. Microsoft Direct X 9 or later, please make sure your graphic card support DirectX 9 at least.
. Adobe� Reader XI (11.0.6) or later [OPTIONAL for Launcher Manuals Tab] (Even if Acrobat is installed).
  If you have Adobe� Acrobat� installed, run the Adobe Reader, go to edit>preference, select General, click Use default pdf handler.
  This will make Adobe� Acrobat� the default program for pdf file and active the active x control for My Nes.

Copying
-------
This program is free software: you can redistribute it and/or modify it under the terms of the 
GNU General Public License as published by the Free Software Foundation, either version 3 of the License, 
or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. 
If not, see <http://www.gnu.org/licenses/>.

NES is either a trademark or registered trademark of Nintendo of America Inc.
Famicom is either a trademark or registered trademark of Nintendo Co., LTD.
All other trademarks are property of their respective owners.
My Nes is not affiliated with or endorsed by any of the companies mentioned. 
Read the "Copyright Notice.txt" file included in this release for list of used component licenses.

Truobleshooting
---------------
. My Nes doesn't run at all.	

    Make sure your pc meet the System Requirements
    Try installing the SlimDX Runtime .NET 4.0 x86 (January 2012).
    Update you drivers to the latest releases (video card and sound card drivers)
    Try to run My Nes as administrator (right mouse click on My Nes execute file the then choose run as administrator or choose properties then the compatibility tab, check the run as administrator.

. My Nes used to run normally but suddenly it stop to run and windows show message about find solution.
	
    Try to reset My Nes settings to defaults. To do so, go to "C:\Users\<username>\AppData\Local\MyNes" folder (windows Vista and later) then delete all folders located there.

. The Launcher show errors when attempt to run it (from main menu or using CTRL+Q)
	
    Try to delete (or move) the database file. Normally, the database file is located in My Nes folder called "MyNesDatabase.mndb" either rename it to something else, move it somewhere or delete it. Try to launch the Launcher again. If it works then the problem is with the database and you'll need to create new one.
    Try to reset My Nes settings to defaults. To do so, go to "C:\Users\<username>\AppData\Local\MyNes" folder (windows Vista and later) then delete all folders located there.

. The sound playback get ugly after sometime of playing a game.
	
    Maybe the issue is "losing synchronization". See Audio for details. The solution when this problem occur is to Pause the emulation (press F2) for 2 seconds or more then resume the emulation (press F2 again).
    Maybe the emulation is not running at the required speed. For example, it should run at 60 FPS but it run less (40 FPS) for you. To make sure, enable Show FPS option in the Video setting then run the game. If the FPS is less than 60 FPS for NTSC/50 FPS for PAL then that it is. The only solution is to try to improve performance. See Improve Performance With Frame Skip, Audio .

. The controls doesn't work after disconnecting a joystick	

    You'll need to reconfigure the input settings for that Nes device and set the PC device that should be used for that Nes device. See Inputs.

. State save/Snapshot take/Record sound doesn't work.
	
    Try to run My Nes as administrator (right mouse click on My Nes execute file the then choose run as administrator or choose properties then the compatibility tab, check the run as administrator.

. A game doesn't work (Green/Black/Blue screen on My Nes)

    This mean that game is not supported (not supported mapper) or that game has an issue. There is no solution but to wait for the developers to support the mapper required and/or to fix the issue. You can help by sending a feedback about that game, see Support .

. Game Genie doesn't work after adding codes to the list using the Game Genie window

    Make sure the Activate Game Genie option is enabled in the Game Genie window. See Game Genie
    Make sure the codes you entered are correct.

. The video is not rendering as it should (no smooth frames or shattering)

    Make sure the Frame Skipping is configured well. If it is enabled, it may cause a "not smooth" frames.
    Maybe the emulation is not running at the required speed. For example, it should run at 60 FPS but it run less (40 FPS) for you. To make sure, enable Show FPS option in the Video setting then run the game. If the FPS is less than 60 FPS for NTSC/50 FPS for PAL then that it is. The only solution is to try to improve performance. See Improve Performance With Frame Skip, Audio .

Links:
------

E-Mail: ahdsoftwares@hotmail.com

Main Website include information, forums, source code and more: http://sourceforge.net/projects/mynes/

Article about My Nes on CodeProject.com: http://www.codeproject.com/KB/game/MyNes_NitendoEmulator.aspx

Facebook page: http://www.facebook.com/pages/My-Nes/427707727244076