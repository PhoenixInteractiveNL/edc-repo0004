YANESE - Yet Another NES Emulator

Yanese is a free Nintendo Entertainment System Emulator for Windows XP,Vista, 7 and 8 under x86 and x64 processors.

What it futures:

    * NTSC, PAL, Dendy NES Emulation
    * Scale2x on PPU "Pixel Aspect Ratio": This smooth pixels and shapes and is  the mode that lets "record videos"
    * ROMS Library: Subdir /roms is scanned automatically if you add or delete roms.
    * GUI: Rom list navegable with the Keyboard and the Gamepad (if one is found) and ROM PREVIEW in window 2x and above. 
    * Joypad GUI Navigation: If you have a Gamepad plugged. You can go "up" and "down" the roms list withe the Gampad.
      Pressing "Left" and "Right" is equivallent to Page Up and Down respectivly. Pressing the 4 NES buttons while playing will close the game and returns you to the library.
    * Gamepads: Up to 2 gamepads for playing and one for navigating the "roms" library with autodetection, pluglabble and unpluggable capabilities.
    * Video Recording: Record video of what you are playing in three differents qualities. *Only* avaiblable in "Pixel Aspect Ratio" Mode.
    * Drag and Drop: Drag a .NES file to the window or to the .exe or shortcut and it will load the rom.
    * Command Line: You can pass the path of the rom via command line
    * Volume control: Popup window with "right click" to control volume.
    * Full Screen Wide or 4:3: "Alt + Enter" to toggle to fullscreen and back again. Fullscreen implies "Scale2x".
    * Mappers: MAPPER 0, UNROM, CNROM, MMC1, MMC2, MMC3, MMC4, MMC5 (partial), AOROM,  BxROM, #11, #58, #64,#65,#66,#71, #91, #118, #189, #226.

Take into account that some functions are only available while the ROM is loaded. If not nothing will happen, for example volume control won't appear.

Default Emu Keyboard Keys are:

    * Directions: Up, Down, Right, Left arrow.
    * Buttons:
          o B: Key "A"
          o A: Key "S"
          o Select: Key "Z"
          o Start: Key "X"

This mapping can be changed in "input config" dialog.

GamePads:
They will be autodetected and set up.
Direction analog and digital is auto setup. Buttons can be changed via "Joypad Input Config" Dialog.
The gamepads are plugglable and unplugglable, that means you don't need to re-start or reconfigure the gamepads when you unplugg your gamepad.

Note: Yanese is currently under "Development". Since the way i'm using to save states, expect some errors when you change from a version to another until a "Stable" version is commited.