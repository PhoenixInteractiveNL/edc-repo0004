#include <stdarg.h>
#include <stdio.h>

#define WC_DEGUB_BUFFER_SIZE 128

extern "C" {
void EmuDebug(const char *buffer);
int EmuDebugf(const char *format, ...);
bool IsRunningOnWhineCube();
char *GetWhineCubeVersion(char *buffer);	//buffer should be at least 12 bytes long
}
