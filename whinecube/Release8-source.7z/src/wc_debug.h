#define WC_DEGUB_BUFFER_SIZE 128

extern "C" {
	void EmuDebug(const char *buffer);
	int EmuDebugf(const char *format, ...);
	bool IsRunningOnWhineCube();
	char *GetWhineCubeVersion(char *buffer);	//buffer should be at least 12 bytes long
	void DspQuickExecute(const void* code, int codeSize, void* data, int entryPoint);
}
