// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2 as
// published by the Free Software Foundation.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

#ifndef MESSAGES_H
#define MESSAGES_H

#define _WIN32_WINNT 0x0500
#include <windows.h>

#define LAZER_MESSAGES(macro) \
	macro(LM_VSYNC)\
	macro(LM_DEGUBBERCLOSED)\
	macro(LM_RECOMPILATION_START)\
	macro(LM_RECOMPILATION_FINISH)\
	macro(LM_THREAD_FINISH)\
	macro(LM_ERROR_STRING)\
	macro(LM_ERROR_GLE)\
	macro(LM_GP_ACTIVATED)\
	macro(LM_DEBUG)\
	macro(LM_DEBUG_OUTPUT_CLOSED)\
	macro(LM_GPEXCEPTION)\

#define DECLARE_MESSAGES(message) ,message
enum { _LM_FILLER=WM_USER LAZER_MESSAGES(DECLARE_MESSAGES), LM_LOAD, _LM_END };
#undef DECLARE_MESSAGES

enum { EDO_ADD, EDO_CLEAR, EDO_REPLACE };

#endif	//MESSAGES_H
