// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2 as
// published by the Free Software Foundation.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

#include "degub.h"
#include "corebase.h"

void CoreBase::oovpa_do_section(DWORD /*base_address*/, DWORD /*size*/) {
  /*if(g::advanced_mode) {
    throw generic_fatal_exception(
      "Internal error: Advanced mode doesn't go well with OOVPA!");
  }
  DEGUB("Doing OOVPA section: base=0x%08X | size=%X\n", base_address, size);
  int matches = 0;

  for(DWORD address=base_address; address<base_address+size; address+=4) {
    for(size_t i=0; i<NOOVPAS; i++) {
      DWORD data1 = m.rw(address);
      m.clear_degub();
      DWORD faddress = address - oovpas[i].array[0].offset;
      if(oovpas[i].array[0].opcode == data1) {
	DEGUB("Found 1\n");
	bool match = true;
	for(size_t j=1; j<oovpas[i].alen; j++) {
	  DWORD data2 = m.rw(faddress + oovpas[i].array[j].offset);
	  m.clear_degub();
	  if(oovpas[i].array[j].opcode != data2) {
	    DEGUB("Break\n");
	    match = false;
	    break;
	  }
	  DEGUB("Found %i\n", j);
	}
	if(match) {
	  matches++;
	  DWORD paddress = PHYSICALIZE(faddress);
	  if(g::use_map) {
	    size_t index = get_symbol_index(faddress);
	    if(index != -1) {
	      DEGUB("Matching symbol: %s\n", symbol_array[index].name.c_str());
	    }
	  }
	  //check errors
	  if(oovpas[i].paddress != INVALID_ADDRESS) {
	    DEGUB("OOVPA error no.1: name=%s | old=0x%08X | new=0x%08\n",
	      oovpas[i].name, oovpas[i].paddress, paddress);
	    throw generic_fatal_exception("Internal error: Two matches for one OOVPA!");
	  }
	  for(size_t k=0; k<NOOVPAS; k++) {
	    if(oovpas[k].paddress == paddress) {
	      DEGUB("OOVPA error no.2: paddress=0x%08X | old=%s | new=%s\n",
	      paddress, oovpas[k].name, oovpas[i].name);
	      throw generic_fatal_exception("Internal error: One match for two OOVPAs!");
	    }
	  }
	  oovpas[i].paddress = paddress;
	  //do the patching
	  m.ww(paddress, (IPO_OOVPA << 26) | i);
	  m.clear_degub();
	  DEGUB("Patched 0x%08X for %s\n", paddress, oovpas[i].name);
	}
      }
    }
  }
  DEGUB("%i matches\n", matches);*/
}

DWORD CoreBase::generic_oovpa_func(DWORD /*callee_address*/, DWORD /*i*/) {
  /*MYASSERT(i < NOOVPAS);
  if(PHYSICALIZE(callee_address) != oovpas[i].paddress) {
    DEGUB("OOVPA error no.3: %s called from 0x%08X, should've been 0x%08X\n",
      oovpas[i].name, callee_address, oovpas[i].paddress);
  }
  DWORD return_address = r.lr;
  (this->*oovpas[i].function)();
  return return_address;
  //The implementation of jumping back differs between Cores, so we shan't handle it here.*/
	return r.lr;
}

#define HLE_RETURN(i) { r.gpr[3] = (i); return; }
/*
const OVP CARDUnlock_d[] =
{
  {0x9421fef0, 8},	//stwu	r1,-272(r1)
  {0xbec100e8, 0xC},	//stmw	r22,232(r1)
  {0x7f000278, 0xC8}, 	//xor	r0,r24,r0
  {0x7ce31a38, 0xA70},	//eqv	r3,r7,r3
  {0x4e800020, 0xB38}	//blr
};  //int __CARDUnlock(int channel?, int ???);
void CoreBase::CARDUnlock_f() {
  DEGUB("CARDUnlock_f(%i, %i)\n", r.gpr[3], r.gpr[4]);
  HLE_RETURN(0);
}

//s32 CARDMountAsync (s32 chan, void* workArea, CARDCallback detachCallback, CARDCallback attachCallback);
void CoreBase::CARDMountAsync_f() {
  DWORD channel = r.gpr[3];
  DWORD workArea = r.gpr[4];
  DWORD detachCallback = r.gpr[5];
  DWORD attachCallback = r.gpr[6];
  DEGUB("CARDMountAsync_f(%i, 0x%08X, 0x%08X, 0x%08X)\n",
    channel, workArea, detachCallback, attachCallback);
  if(channel < 0 || channel > 1) {
    HLE_RETURN(-128);
  }
  DWORD cbaddress = CARDBlock + channel*272;
  m.ww(...
}*/

//CoreBase::OOVPA CoreBase::oovpas[NOOVPAS] = {
  //OOVPAS(DECLARE_OOVPA_STRUCT, DECLARE_OOVPA_STRUCT_MIDDLE, NULL_MACRO) };
