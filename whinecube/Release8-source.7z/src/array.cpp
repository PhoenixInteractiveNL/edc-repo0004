// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2 as
// published by the Free Software Foundation.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

#include "array.h"

//int array_new_id = 0;
//int array_break_id = 115;

bool all_true(const Array<bool> &arr) {
	for(DWORD i=0; i<arr.size(); i++)
		if(arr[i] == false)
			return false;

	return true;
}
