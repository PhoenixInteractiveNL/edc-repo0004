#! /bin/sh
echo "$1"
cat GPL2-header.txt "$1" > tmp
mv tmp "$1"
