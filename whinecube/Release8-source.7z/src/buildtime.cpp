const char *g_buildtime = "Build date: " __DATE__ " " __TIME__ " CET";
