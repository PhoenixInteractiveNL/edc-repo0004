WhineCube release 4, version 0.3.8  (C) 2004
2004-06-27

WhineCube is a GameCube emulator. It loads and executes DOL- or ELF-format executables with graphics, pad and sound emulation, and can also provide massive debug dumps. It has two different cores, an interpreter and a dynamic recompiler. There is also a primitive (and little-used) HLE system.


Requirements:
Windows xp or later (it might run on Win2k, but I wouldn't bet on it)
DirectX 9.0b
Graphics card/drivers that support D3DFMT_YUY2 conversion


Usage: whinecube [filename.dol] [switches]

Emulation options:
/cache		Activate a very simple cache memory implementation. This takes care of a
		few early demos which would not work when loaded with something other than
		PSUL 1.0. It may cause or fix problems in other demos, too.
/gcm <filename>	Load the specified GCM file at startup and close the emulated lid.
/rec		Use the recompiling core.
/interp		Use the interpreting core.
/rti		Enable sensitive dynamic recompilation. For use with selfmodifying code.
		If it works in the interpreter but not in the recompiler, try this.
/amode		Enable advanced memory translation mechanisms (BATs and page tables),
		as well as sensitive dynarec. For use with very advanced stuff (gc-linux).
/nohle		Disable HLE.
/noap		Disable auto-pause when window loses focus.

Logging options:
/daudio		Dump all sounds played using DMA to disk, raw 16-bit stereo PCM,
		big endian.
/quiet		Mute any sound played using DMA. Works well with /daudio.
/disasm		Disassembly mode. Rather messy at the moment, but it gets the job done.
/degub		Dump debug info for every instruction executed. Slow and spacy.
/skip%i		As /degub, except for the first %i instructions. Ex: /skip2130000
/nodegub	Turn off degub mode.
/dumpmem	Dump main, cache and hardware memory on exit.
/beep		Emit a low-pitch beep through the PC speaker when a vsync access is detected,
		a high beep when pad access is detected and
		a medium beep when recompilation starts/stops.
/bouehr		Break On UnEmulated Hardware or SPR access.
/lowmem		Activate special logging for accesses to the low memory area (0 - 0x3100).
		Implies /interp.
/recd		Use the recompiling core and disassembles the recompiled areas.
/lint		Log interrupts.
/dump_textures	Dump GX textures when they're referenced by the program.
		File names are like this: <gcformat><format>_<address>.raw.
		<gcformat> is the source format, a digit from 0 to 6.
		<format> describes the file format. Can be rgb, i(intensity), a(alpha) or t(source format).
		<address> is the physical address of the texture in GameCube memory.

Most command-line switches are also available through the Options menu.


Known issues:
* PSOLoad2-style DOL reloading is not supported at this time. Attempting it will result in an undefined opcode encounter.
* Vsync detection is tricky business. When WhineCube is unable to dectect new frames, the screen is updated at a fixed rate, which defaults to one FPS. You may use the "High refresh rate" option, though doing so will slow the emulation down somewhat.
* BBA emulation has been nerfed until further notice. (The emulation is active, but no packets are actually sent or recieved.)


Thanks:
To DesktopMan and the author of http://www02.so-net.ne.jp/~koujin/jpeg/RGB2YCbCr.html for YUYV info.
To Crazy Nation for lots of useful info in their Source Pack.
To Peter of www.console-dev.de and to Yursoft for YUYV and Pad info in their OpenGC library.
To CrowTRobo for his Audio Demo.
To Epsilon and RealityMan (UltraHLE) for the analog modifier key idea.
To or9 for Dolwin.
To Costis for GCLIB.
To tmbinc for his IPL and 3D code.
To groepaz for YAGCD.
To monk for gcube.
To ector and F|RES for Dolphin.

Special Thanks:
To Nullsoft for WinAMP.
To sleeps for the WhineCube logotype and icon.


WhineCube was written using Microsoft Visual C++, the DirectX9 SDK and the pngdib library.


Web site: http://whinecube.emulation64.com/

Contact the author:
IRC: Masken in #whinecube on Efnet
e-mail: masken@emulation64.com
