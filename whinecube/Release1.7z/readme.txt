WhineCube release 1, version 0.3.3  (C) 2004
2004-06-12

WhineCube is a GameCube emulator. Its primary function is to load and execute a DOL-format executable with graphics, pad and sound emulation, and optionally provide massive debug dumps. It has two different cores, an interpreter and a dynamic recompiler. There is also a primitive HLE system.


Requirements:
Windows xp or later (it might run on Win2k, but I wouldn't bet on it)
DirectX 9.0b
DirectX8-compatible graphics drivers


Gamepad mapping:
Gamepad 0	PC Keyboard
A		A
B		X
Z		Z
X		S
Y		Q
START		C
D-pad		TFGH

Analog 1/2 mod	Shift
Analog 1/4 mod	Ctrl
L		W
R		E
Analog stick	Arrow keys
C-stick		IJKL


Usage: WhineCube [filename.dol] [switches]

Emulation options:
/cache		Activate a workaround for the cache problems a few early demos has
		when loaded with something other than PSUL 1.0.
/gcm <filename>	Load the specified GCM file at startup and close the emulated lid.
/rec		Use the recompiling core.
/interp		Use the interpreting core.
/rti		Enable sensitive dynamic recompilation. For use with selfmodifying code.
		If it works in the interpreter but not in the recompiler, try this.
/amode		Enable advanced memory translation mechanisms (BATs and page tables),
		as well as sensitive dynarec. For use with very advanced stuff (gc-linux).

Logging options:
/daudio		Dump all sounds played using DMA to disk, raw 16-bit stereo PCM,
		big endian.
/quiet		Mute any sound played using DMA. Works well with /daudio.
/disasm		Disassembly mode. Rather messy at the moment, but it gets the job done.
/degub		Dump debug info for every instruction executed. Slow and spacy.
/skip%i		As /degub, except for the first %i instructions. Ex: /skip2130000
/nodegub	Turn off degub mode.
/dumpmem	Dump main, cache and hardware memory on exit.
/beep		Emit a low-pitch beep when a vsync access is detected,
		a high beep when pad access is detected and
		a medium beep when recompilation starts/stops.
/bouehr		Break On UnEmulated Hardware or SPR access.
/nohle		Disable HLE.
/lowmem		Activate special logging for accesses to the low memory area (0 - 0x3100).
		Implies /interp.
/recd		Use the recompiling core and disassembles the recompiled areas.
/lint		Log interrupts.

Most command-line switches are also available through the Advanced Options dialog.


Known issues:
* PSOLoad2-style DOL reloading is not supported at this time. Attempting it will result in an undefined opcode encounter.
* Frame detection is tricky business. When WhineCube is unable to dectect new frames, the screen is updated at a fixed rate, which defaults to one FPS. You may change this rate to 50 FPS, though doing so will slow the emulation down somewhat.
* BBA emulation has been mostly disabled until further notice.


Thanks:
To DesktopMan and the author of http://www02.so-net.ne.jp/~koujin/jpeg/RGB2YCbCr.html for YUYV conversion information.
To Crazy Nation for lots of useful info.
To Peter of www.console-dev.de and to Yursoft for YUYV and Pad info in their OpenGC library.
To CrowTRobo for his Audio Demo.
To Epsilon and RealityMan (UltraHLE) for the analog modifier key idea.
To or9 for Dolwin.
To Costis for GCLIB.
To tmbinc for his IPL and 3D code.
To groepaz for YAGCD.

Special Thanks:
To Nullsoft for WinAMP.
To sleeps for the WhineCube logotype and icon.


Contact the author:

IRC: Masken, #gcdev, Efnet
e-mail: masken@emulation64.com
web: whinecube.emulation64.com
