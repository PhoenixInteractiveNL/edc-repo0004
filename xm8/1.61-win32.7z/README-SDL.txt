
Please distribute this file with the SDL runtime environment:

The Simple DirectMedia Layer (SDL for short) is a cross-platform library
designed to make it easy to write multi-media software, such as games and
emulators.

The Simple DirectMedia Layer library source code is available from:
http://www.libsdl.org/

This library is distributed under the terms of the zlib license:
http://www.zlib.net/zlib_license.html


* NOTICE *
This version of SDL2.dll is version 2.0.3-based and add a patch to fix the
problem SDL delivers Windows 8.x touch event without SDL_MOUSE_TOUCHID.
https://bugzilla.libsdl.org/show_bug.cgi?id=2726
