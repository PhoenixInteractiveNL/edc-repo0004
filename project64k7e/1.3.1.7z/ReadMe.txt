Update by Gaudy -------------------------------------------------------------------------------------------------------

Update 02/11/2012 -----------------------------------------------------------------------------------------------------

		* Actualizado RDB y RDX soporte SM64 Multiplayer Hack 1.0 y 1.1 by Skelux

Update ??/03/2012 -----------------------------------------------------------------------------------------------------
		* Agregada la actualizaci�n NRage Input Plugin v2.3 Final, Este corrige algunos errores importante del 2.2 Bet. Thx to squall-leonhart
		* Agregada la actualizaci�n n02 to release 18, thx to Ownasaurus
		* Correcci�n algunos cheats PSA con tal de evitar Freeze, otros PSA se eliminaron vi�ndose q no ten�an soluci�n
		* Se descubri� otro causante de ds, Buffer Vsync, por lo que si desea jugar en Fullscreen, podr� hacerlo, pero por default siempre ser� con Transfer Memory para evitar desincronizaciones.
		* Agregado un archivo .reg para activar cheats de tipo "Have All", por lo q es de importancia y �til para los newbies.
		* Eliminado error al intentar leer Krecs, puesto q el �nico causante de este es cuando no existe dicha carpeta.
		* No agregado Manifest debido a que algunos chipset y ordenadores antiguos tienen problemas con D3D8 luego de un par de juegos
		* Casual Image Freeze Fixed
		* Deshabilitada la opci�n RAWDATA del NRage 2.3 para evitar problemas en Netplay
		* "Acerca de" ahora mensiona los correct Thanks to and Greetings
		* Agregado al RDX algunos Good Verif.Dump en GoodName
			[6D6AF5BB-88D471E8-C:4A]
			[DC3BAA59-0ABB456A-C:45]
			[2E0E7749-B8B49D59-C:58]
			[2E0E7749-B8B49D59-C:58]
			[665F09DD-FC3BAC53-C:50]
			[F82DD377-8C3FB347-C:58]
			[9A746EBF-2802EA99-C:0]
			[1A7F70B5-00B7B9FD-C:45]
			[21260D94-06AE1DFE-C:45]
			[486BF335-034DCC81-C:46]
			[6C2C6C49-9BE5CA66-C:45]
			[EC7011B7-7616D72B-C:4A]
			[D43DA81F-021E1E19-C:4A]
			[693BA2AE-B7F14E9F-C:4A]
			[F7F52DB8-2195E636-C:4A]
			[F43B45BA-2F0E9B6F-C:4A]
			[F611F4BA-C584135C-C:4A]
			[EC417312-EB31DE5F-C:4A]
			[69AE0438-2C63F3F3-C:4A]
			[8473D0C1-23120666-C:4A]
			[1C010CCD-22D3B7FA-C:4A]
		

Update K7E 1.3 b2 - 24/08/2011 ----------------------------------------------------------------------------------------

		* Added some Importantes Comentaries on CHT about NetPlay stabilities
		* Added OoT Cheats multiplayer
		* Added 3 more games Support
		* Added NetPlay Input Plugin 0.2 (alternative P2P NetPlay)
		* Changed Audio Plugin by Azimers 0.30
		* Minors Fixes

Update K7E 1.3 b1 - 15/6/2011 -----------------------------------------------------------------------------------------

		* Added some Importantes Comentaries on CHT about NetPlay stabilities
		* Added support for 3 more games
		* Added NetPlay Input Plugin 0.13 (alternative P2P NetPlay)
		* Deleted Jabo D3D8 1.7, not stable build for 1.4
		* Minors Fixes

Update 03/04/2011 ------------------------------------------------------------------------------------------------------
		
	Update EXE (03/04/2011)
		* Corregid� el error de la Des-Elecci�n de Plugins. Gracias a Henryxs87
		* Los archivos de carga de configuraci�n se encuentran ahora en Carpeta Config para mejor presentaci�n
		* Se dio una mejor compresi�n al igual que los demas dll
		* Integrado archivo .Manifest independiente (con tal el q si se necesite eliminar, lo puedan hacer a mano)
		* Nuevos Atajos de teclado. Gracias a Henryxs87
			F11 = Iniciar Emulacion
			F12 = Cerrar Juego (Funcion que recuerda al Project64 1.6 y 1.7)
			Ctrl + C = para cargar sus cheats
			Ctrl + T = Para acceder la configuracion(Antes era Ctrl + S, pero lo cambie)
			Ctrl + S = Para Guardar la partida
		
	Update CHT (01/04/2011)
		* Se implement� el 3� avance CHT especial para Kaillera, como se trata de una adaptacion, se elimino todo codigo en SSB q no soporta el Kaillera, ahora ya no habr� demoras de carga de Activaci�n o desactivacion de Cheats
		* El soporte de Cheats se reestableci� a 300, (prefer� dejarlo en los 300, puesto q como el CHT ya fue comprimido y varios de los juegos q mas se juegan tienen menos de 300, encuentro q es innecesario aumentar el soporte, ademas ya no se caer� mas cuando clickeamos en Seleccionar/Dsactivar todas)
		* Se agregaron 4000 Cheats mas (4000 mas que la version aneterior) especialmente en los juegos mas Jugados en Kaillera (Mario Party, Mario Kart, Golden Eye, etc...)
		
	Plugins PRE-DEFINIDOS:
		Grafico: Jabos Direct3D8 1.6
		Audio:   Jabos Direct Sound 1.6 (para regular el volumen)
		Control: NRage 1.61 (no se puso versiones superiores puesto q tienen Bugs importants en los Controls Modifiers, lo q imposibilita el movimiento en ciertos momentos)
		
	Otros Cambios:
		* Se integro el RDX del PJ64 1.7.0.50b23
		* Se integro el Jabo's Direct3D8 1.7.0.46 para los q les gusta jugar con Texturas. Gracias a Henryxs87
		* Eliminado el RAW DATA de NRage 1.61, ya q este comando imposibilitaba el movimiento de Mando durante las partidas Online, el NRAGE siempre se inicializaba con esta opcion activada, pero ahora ya no =), aunq atravez de otra instancia lo active, tambien se puede desactivar dicha opcion desde K7E aun sin q estee el BOX !!
		* Tambien se desactiv� la opci�n "Mostrar CPU %", ya q esta opcion no permite leer los mensajes de Chat durante las partidas Online
		
		
Update 18/08/2010 ------------------------------------------------------------------------------------------------------

	Update EXE (18/08/2010) 
		* Fue eliminada la restriccion de carga de Plugin de por Defecto
        * Tambien le dio interfaz Manifest sin error (eso nunca pude hacer uno estable XD)
        * y otros q desconosco...
		Gracias a Ginzuhayate [Tema]
        * Tambien se aumento el Numero limite de soportes de Cheats de 300 a 2000
        * Acceso directo a los Cheats Ctrl + C
        * Bloqueado Mostrar Uso CPU, ya me ha tocado jugar con gente q lo tiene actuivado lo q impide recibir los mensajes
		Gracias a Gaudy

	Update RDB (01/04/2010) 
		Este vendria siendo el archivo q contiene las configuraciones predeterminadas de cada juego. Este fue reeditado unicamente los Nombres de los ROMs para q fueran compatibles con PJ64K y PJ64KVE
        * Reconoce 770 juegos -> 892 juegos
		Gracias a Henryxs87 por trabajar en �l asi como tambien a�adir el trabajo de DigitalSpider, Nekokabu y MASA [Tema]

	Update RDX (01/04/2010)
		Es el archivo q almacenan algunas caracteristicas y especificaciones de los ROMs, asi como sus Nombres, Compa�ia, jugadores, Generos, Activacion/Desactivacion Vibracion del Joystick, etc...
        * Podr�n saber cuales ROMs de su coleccion es Multiplayer y podran conocer los generos de cada uno, de carrera, de pelea, aventura, etc... lo q anteriormente el 1.4 no lo permitia con el RDB de se version
		Gracias a Henryxs87 [Tema]

	Update CHT (Avance12 - 16/08/2010) 
		Este contiene los Cheats de Todos los juegos
        * Aumentado de 5000 Lineas de Codigo a 24700 Linea de Codigo
		Gracias a Gaudy
		Gracias a Dark, Gaudy y Nokaubure por los Cheats de SSB [Tema]

	Update Kaillera DLL (n02 r17 - 24/06/2010) 
		Este es el cliente Kaillera q nos permite conectarnos ya sea por servidor o por P2P
        * Bastantes mejoras
		Gracias a Ownasaurus [Tema] 

	
www.emudigital.net
