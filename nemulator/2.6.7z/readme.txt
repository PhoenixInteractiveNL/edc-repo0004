nemulator
Copyright (C) 2003-2011 James Slepicka
http://nemulator.com

nemulator uses the Nes_Snd_Emu library, licensed under the GNU Lesser Public License (LGPL); see LGPL.txt.
Nes_Snd_Emu Copyright (C) 2003-2005 Shay Green
http://slack.net/~ant/libs

visit nemulator.com for additional info