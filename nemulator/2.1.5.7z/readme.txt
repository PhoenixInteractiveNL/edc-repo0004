nemulator 2.0 beta 2
Copyright (C) 2003-2009 James Slepicka
http://nemulator.com

nemulator uses the Nes_Snd_Emu library, licensed under the GNU Lesser Public License (LGPL); see LGPL.txt.
Nes_Snd_Emu Copyright (C) 2003-2005 Shay Green
http://slack.net/~ant/libs

Requirements

nemulator 2.0 uses DirectX 10, therefore Windows Vista or Windows 7 is required.
If you receive an error message stating that d3dx10_33.dll is missing, please download
the latest DirectX 10 update from Microsoft at microsoft.com (1).

You need a lot of horsepower (probably a dual-CPU/core system) to run the menu at full speed.

(1) http://www.microsoft.com/downloads/details.aspx?FamilyId=2DA43D38-DB71-4C1B-BC6A-9B6652CD92A3&displaylang=en
