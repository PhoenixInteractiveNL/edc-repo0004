// initguid.h

#include "Common/MyInitGuid.h"

