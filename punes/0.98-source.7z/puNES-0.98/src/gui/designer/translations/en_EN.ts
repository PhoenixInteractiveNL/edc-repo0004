<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_EN">
<context>
    <name>APU_channels</name>
    <message>
        <source>APU Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DMC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Cheats</name>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Game Genie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CPU Ram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pro Action Rocky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cheat Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cheats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Input_dialog</name>
    <message>
        <source>Input Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controllers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller Port 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller Port 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller Port 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller Port 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permit &quot;Up + Down&quot; and &quot;Left + Right&quot; at the same time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Joystick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Joystick ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Set_borders</name>
    <message>
        <source>Set borders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Overscan borders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Standard_Pad</name>
    <message>
        <source>Standard Pad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turbo B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turbo A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unset all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Joystick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turbo B Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turbo A Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Uncompress_selection</name>
    <message>
        <source>Unpacked archive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Roms</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cheatObject</name>
    <message>
        <source>Error on reading the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file is in read only mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dlgCheats</name>
    <message>
        <source>XML files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Cheats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export cheats on file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CHT files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All supported formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Submit warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The code is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The cheat is already in the list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dlgInput</name>
    <message>
        <source>NES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Famicom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Four Score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard Pad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zapper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No usable device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error on open device %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press a key (ESC for the previous value &quot;%1&quot;) - timeout in %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error on reading controllers configurations</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dlgOverscanBorders</name>
    <message>
        <source>NTSC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PAL/Dendy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dlgStdPad</name>
    <message>
        <source>Controller %1 : Standard Pad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3rd-party</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No usable device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select device first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error on open device %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error on reading controllers configurations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press a key (ESC for the previous value &quot;%1&quot;)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mainWindow</name>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hard Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Soft Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Eject/Insert Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk 1 side A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk 1 side B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk 2 side A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk 2 side B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk 3 side A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk 3 side B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk 4 side A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk 4 side B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Switch sides</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;PAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;NTSC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Dendy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>59</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>58</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>57</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>55</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>54</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>53</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>52</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>51</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>50</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>49</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>47</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>46</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>45</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>44</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>O&amp;ff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Set borders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;No Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Phosphor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Phosphor2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;canline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;DBL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark R&amp;oom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;CRT With Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;CRT Without Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scale2X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scale3X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scale4X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hq2X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hq3X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hq4X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;xBRZ 2X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;xBRZ 3X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;xBRZ 4X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;NTSC Composite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;NTSC S-Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;NTSC RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;ony CXA2025AS US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Monochrome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load from file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Enable Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;ave state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L&amp;oad state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Disable Red and Green emphasis swap for PAL/Dendy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setti&amp;ngs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;VSync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Interpolation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Te&amp;xt on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F&amp;ullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;tretch in fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;44100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4&amp;8000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;22050</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;11025</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>15%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>20%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30% (Default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>35%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>40%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>45%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>55%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>65%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>70%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>80%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>85%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>90%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>95%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A&amp;PU channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;wap Duty Cycles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause when &amp;in background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save se&amp;ttings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save settings on e&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Increment slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Decrement slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Recent Roms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;NES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Disk Side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rendering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;FPS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fra&amp;me skip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pixel Aspect Ra&amp;tio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Overscan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De&amp;fault value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fi&amp;lter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Sample rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;tate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OpenGL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OpenGL &amp;GLSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GLSL &amp;soft stretch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HLSL &amp;soft stretch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Insert disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Eject disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Eject/Insert disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Select a file]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All supported formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compressed files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nes rom files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FDS image files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TAS movie files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Palette files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save palette on file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open palette file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save states</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save state on file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open save state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nintendo Entertainment System Emulator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot &amp;9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Game Genie Rom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cheats List Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cheats &amp;Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Anyway, thank you all for the love and the help.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you like the emulator and you want to support it&apos;s development or would you pay for a beer at the programmer :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;HLSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;1:1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;8:7 (NTSC TV)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>portable version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Stereo Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stereo &amp;Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Buffer Size factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Fast Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;2x (Default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;3x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;4x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;5x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;1 (Default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Fast Forward velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cheats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Channels Delay</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>stateWidget</name>
    <message>
        <source>Save/Load Slot Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slot %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeLine</name>
    <message>
        <source>sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-00 sec</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
