// HelpUtils.h

#ifndef __HELPUTILS_H
#define __HELPUTILS_H

#include "Common/MyString.h"

void ShowHelpWindow(HWND hwnd, LPCWSTR topicFile);

#endif
