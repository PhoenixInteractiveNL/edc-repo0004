#define IDD_DIALOG_PASSWORD             501
#define IDC_STATIC_PASSWORD_HEADER      1000
#define IDC_EDIT_PASSWORD               1001
#define IDC_CHECK_PASSWORD_SHOW         1002
