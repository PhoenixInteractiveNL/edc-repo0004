#define IDD_LANG           544
#define IDD_LANG_2         644

#define IDS_LANG_ENGLISH   995
#define IDS_LANG_NATIVE    996

#define IDC_LANG_STATIC_LANG            1000
#define IDC_LANG_COMBO_LANG             1001
