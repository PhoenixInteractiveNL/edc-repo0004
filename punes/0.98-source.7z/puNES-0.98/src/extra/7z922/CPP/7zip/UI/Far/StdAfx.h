// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#define _CRT_SECURE_NO_DEPRECATE
#include <windows.h>
#include <stdio.h>

#include "Common/NewHandler.h"

#endif

