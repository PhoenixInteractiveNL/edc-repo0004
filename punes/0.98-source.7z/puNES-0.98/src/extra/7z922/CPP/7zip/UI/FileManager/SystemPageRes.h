#define IDD_SYSTEM                      540
#define IDD_SYSTEM_2                    640
#define IDS_PLUGIN                      990
// #define IDC_SYSTEM_INTEGRATE_TO_CONTEXT_MENU 1010
#define IDC_SYSTEM_STATIC_ASSOCIATE     1020
#define IDC_SYSTEM_LIST_ASSOCIATE       1021
// #define IDC_SYSTEM_LIST_PLUGINS         1022
// #define IDC_SYSTEM_SELECT_ALL           1023
#define IDC_SYSTEM_BUTTON_CURRENT       1024
#define IDC_SYSTEM_BUTTON_ALL           1025
