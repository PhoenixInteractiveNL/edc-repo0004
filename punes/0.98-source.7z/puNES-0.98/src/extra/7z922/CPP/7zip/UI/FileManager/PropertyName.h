// PropertyName.h

#ifndef __PROPERTYNAME_H
#define __PROPERTYNAME_H

#include "Common/MyString.h"

UString GetNameOfProperty(PROPID propID, const wchar_t *name);

#endif
