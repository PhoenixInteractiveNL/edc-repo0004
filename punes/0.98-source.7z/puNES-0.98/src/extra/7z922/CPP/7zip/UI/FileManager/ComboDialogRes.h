#define IDD_DIALOG_COMBO                505

#define IDC_COMBO_STATIC                1000
#define IDC_COMBO_COMBO                 1001
