#define IDI_ICON  1

#define IDS_INCORRECT_VOLUME_SIZE       95

#define IDS_FILES_COLON                 2274
#define IDS_FOLDERS_COLON               2275
#define IDS_SIZE_COLON                  2276

#define IDS_PROGRESS_TESTING            4100
#define IDS_MESSAGE_NO_ERRORS           4200
