#define IDD_PLUGINS                     541
#define IDC_PLUGINS_STATIC_PLUGINS      1000
#define IDC_PLUGINS_LIST                1001
#define IDC_PLUGINS_BUTTON_OPTIONS      1002
