#define IDD_DIALOG_PROGRESS          500

#define IDC_PROGRESS1                1000
