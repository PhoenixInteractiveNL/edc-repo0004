#!/bin/bash

autoreconf -vif
