GCEmu
======

Started code: 2004-6-18
First public release: 2005-12-11

Credits: 
========
Duddie - HW reverse engineering
Tratax - CPU recompiler and most of interpreter
Pete Bernert - Graphics plugin
Fires (Dolphin Emu) - Allowing us to greatly improve the emulation by doing a source code exchange
PearPC - We used their interpreter as a starting point for the emulator
Org (Dolwin) - Thanks for your disassembler and general ideas from the source
Costis - Information on how to make the Gamecube boot from an SDcard so we can use it for reverse engineering
All others that supported us during development of this emulation

What is it:
===========
GCEmu is a very incomplete emulator for the Nintendo Gamecube. 
It uses recompilation techniques and some other tricks to achieve a reasonable speed.
Although emulation is very incomplete, this emulation shows that 'it can be done' and can be done at a decent speed.

Where Dolphin Emu shows that the emulation can be done, GCEmu shows that it can be done at speed.
This is because the different focus. Where the Dolphin guys hate to do cpu emulation (especially recompilers) 
this is exactly what I (Tratax) have been playing with since PSEmu.

It was made using Visual Studio C++ using pure C code and a few bits of assembler.

How to use it:
==============
GCEmu <gamename.gcm> 

Keyboard controls:
1 - START
Y - Y
X - X
Z - Z
[ - Button L
] - Button R
I,J,K,L - Digital keypad
Up, Left, Down, Right - Analog stick
E,S,D,F - C analog stick

Future releases:
================

Just like the Dolphin team we've had our moments of working on the code day and night and then a few months of
not even opening Visual Studio. 
After 5 months of idling (last modified was 2005-7-14) we decided to release it and also release the sourcecode
in the hopes that someone more motivated can use it to get some new ideas and maybe improve it. 
Who knows, maybe we will even get motivated again ourselves and do some work on it.
