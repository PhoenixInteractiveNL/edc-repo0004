/*====================================================================

filename:     trx_ppc_rec_fpu_ps_opcodes_x87.h
project:      GCemu
created:      2004-6-18
mail:		  duddie@walla.com

Copyright (c) 2005 Duddie & Tratax

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

====================================================================*/
#pragma once

//fpu
void trx_ppc_gen_fresx(void);
void trx_ppc_gen_fdivx(void);
void trx_ppc_gen_faddx(void);
void trx_ppc_gen_fmsubx(void);
void trx_ppc_gen_fmaddx(void);
void trx_ppc_gen_fnmsubx(void);
void trx_ppc_gen_fnmaddx(void);
void trx_ppc_gen_fdivsx(void);
void trx_ppc_gen_fsubsx(void);
void trx_ppc_gen_faddsx(void);
void trx_ppc_gen_fmulsx(void);
void trx_ppc_gen_fmaddsx(void);
void trx_ppc_gen_fmsubsx(void);
void trx_ppc_gen_fnmsubsx(void);
void trx_ppc_gen_fnmaddsx(void);
void trx_ppc_gen_fselx(void);
void trx_ppc_gen_fcmpu(void);
void trx_ppc_gen_fctiwzx(void);
void trx_ppc_gen_fctiwx(void);
void trx_ppc_gen_frsqrtex(void);
void trx_ppc_gen_fcmpo(void);
void trx_ppc_gen_mtfsb1x(void);
void trx_ppc_gen_mtfsb0x(void);
void trx_ppc_gen_mffsx(void);
void trx_ppc_gen_mcrfs(void);
void trx_ppc_gen_mtfsfx(void);
void trx_ppc_gen_fnegx(void);
void trx_ppc_gen_fmrx(void);
void trx_ppc_gen_fabsx(void);
void trx_ppc_gen_fnabsx(void);
void trx_ppc_gen_fsubx(void);
void trx_ppc_gen_fmulx(void);
void trx_ppc_gen_frspx(void);
void trx_ppc_gen_lfs(void);
void trx_ppc_gen_lfsu(void);
void trx_ppc_gen_lfsx(void);
void trx_ppc_gen_lfsux(void);
void trx_ppc_gen_lfd(void); 
void trx_ppc_gen_lfdu(void); 
void trx_ppc_gen_lfdx(void); 
void trx_ppc_gen_lfdux(void); 
void trx_ppc_gen_stfs(void); 
void trx_ppc_gen_stfsu(void);
void trx_ppc_gen_stfsx(void);
void trx_ppc_gen_stfsux(void);
void trx_ppc_gen_stfd(void);
void trx_ppc_gen_stfdu(void);
void trx_ppc_gen_stfdx(void);
void trx_ppc_gen_stfdux(void);
void trx_ppc_gen_stfiwx(void);

// decoding
void trx_ppc_gen_group59(void);
void trx_ppc_gen_group63(void);
void trx_ppc_gen_gekko(void);
void trx_ppc_gen_dcbz_l(void);
// gekko
void trx_ppc_gen_psq_l(void);
void trx_ppc_gen_psq_lu(void);
void trx_ppc_gen_psq_st(void);
void trx_ppc_gen_psq_stu(void);
void trx_ppc_gen_psq_lx(void);
void trx_ppc_gen_psq_lux(void);
void trx_ppc_gen_psq_stx(void);
void trx_ppc_gen_psq_stux(void);
void trx_ppc_gen_ps_cmpu0(void);
void trx_ppc_gen_ps_cmpo0(void);
void trx_ppc_gen_ps_cmpu1(void);
void trx_ppc_gen_ps_cmpo1(void);
void trx_ppc_gen_ps_neg(void);
void trx_ppc_gen_ps_mr(void); 
void trx_ppc_gen_ps_nabs(void);
void trx_ppc_gen_ps_abs(void); 
void trx_ppc_gen_ps_sum0(void);
void trx_ppc_gen_ps_sum1(void);
void trx_ppc_gen_ps_muls0(void);
void trx_ppc_gen_ps_muls1(void);
void trx_ppc_gen_ps_madds0(void);
void trx_ppc_gen_ps_madds1(void);
void trx_ppc_gen_ps_merge00(void);
void trx_ppc_gen_ps_merge01(void);
void trx_ppc_gen_ps_merge10(void);
void trx_ppc_gen_ps_merge11(void);
void trx_ppc_gen_ps_div(void);
void trx_ppc_gen_ps_sub(void);
void trx_ppc_gen_ps_add(void);
void trx_ppc_gen_ps_sel(void);
void trx_ppc_gen_ps_res(void);
void trx_ppc_gen_ps_mul(void);
void trx_ppc_gen_ps_rsqrte(void);
void trx_ppc_gen_ps_msub(void);
void trx_ppc_gen_ps_madd(void);
void trx_ppc_gen_ps_nmsub(void);
void trx_ppc_gen_ps_nmadd(void);
