/*====================================================================

filename:     trx_ppc_int_opcodes.h
project:      GCemu
created:      2004-6-18
mail:		  duddie@walla.com

Copyright (c) 2005 Duddie & Tratax

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

====================================================================*/
#pragma once

void trx_ppc_int_bclrx(void);
void trx_ppc_int_mtsr();
void trx_ppc_int_mtsrin();
void trx_ppc_int_mfsr();
void trx_ppc_int_mfsrin();
void trx_ppc_int_rfi(void);
void trx_ppc_int_crxor(void);
void trx_ppc_int_cror(void);
void trx_ppc_int_crnor(void);
void trx_ppc_int_crand(void);
void trx_ppc_int_creqv(void);
void trx_ppc_int_bcctrx(void);
void trx_ppc_int_cmp(void);
void trx_ppc_int_subfcx(void);
void trx_ppc_int_addcx(void);
void trx_ppc_int_mulhwux(void);
void trx_ppc_int_mfcr(void);
void trx_ppc_int_lwzx(void);
void trx_ppc_int_lwzux(void);
void trx_ppc_int_slwx(void);
void trx_ppc_int_cntlzwx(void);
void trx_ppc_int_andx(void);
void trx_ppc_int_nandx(void);
void trx_ppc_int_cmpl(void);
void trx_ppc_int_subfx(void);
void trx_ppc_int_andcx(void);
void trx_ppc_int_mulhwx(void);
void trx_ppc_int_mfmsr(void);
void trx_ppc_int_lbzx(void);
void trx_ppc_int_lbzux(void);
void trx_ppc_int_negx(void);
void trx_ppc_int_norx(void);
void trx_ppc_int_subfex(void);
void trx_ppc_int_subfzex(void);
void trx_ppc_int_addex(void);
void trx_ppc_int_mtcrf(void);
void trx_ppc_int_mcrxr(void);
void trx_ppc_int_mcrf(void);
void trx_ppc_int_icbc(void);
void trx_ppc_int_sc(void);
void trx_ppc_int_mtmsr(void);
void trx_ppc_int_stwx(void);
void trx_ppc_int_stfiwx(void);
void trx_ppc_int_stwux(void);
void trx_ppc_int_stwbrx(void);
void trx_ppc_int_stswi(void);
void trx_ppc_int_addzex(void);
void trx_ppc_int_stbx(void);
void trx_ppc_int_stbux(void);
void trx_ppc_int_addmex(void);
void trx_ppc_int_mullwx(void);
void trx_ppc_int_addx(void);
void trx_ppc_int_lhzx(void);
void trx_ppc_int_lhzux(void);
void trx_ppc_int_xorx(void);
void trx_ppc_int_eqvx(void);
void trx_ppc_int_mfspr(void);
void trx_ppc_int_mftb(void);
void trx_ppc_int_sthx(void);
void trx_ppc_int_sthbrx(void);
void trx_ppc_int_orx(void);
void trx_ppc_int_orcx(void);
void trx_ppc_int_divwx(void);
void trx_ppc_int_divwux(void);
void trx_ppc_int_mtspr(void);
void trx_ppc_int_divwux(void);
void trx_ppc_int_srwx(void);
void trx_ppc_int_srawx(void);
void trx_ppc_int_srawix(void);
void trx_ppc_int_extshx(void);
void trx_ppc_int_extsbx(void);
void trx_ppc_int_mulli(void);
void trx_ppc_int_subfic(void);
void trx_ppc_int_cmpli(void);
void trx_ppc_int_cmpi(void);
void trx_ppc_int_addic(void);
void trx_ppc_int_addic_(void);
void trx_ppc_int_addi(void);
void trx_ppc_int_addis(void);
void trx_ppc_int_bcx(void);
void trx_ppc_int_bx(void);
void trx_ppc_int_rlwimix(void);
void trx_ppc_int_rlwinmx(void);
void trx_ppc_int_rlwnmx(void);
void trx_ppc_int_ori(void);
void trx_ppc_int_oris(void);
void trx_ppc_int_xori(void);
void trx_ppc_int_xoris(void);
void trx_ppc_int_andi_(void);
void trx_ppc_int_andis_(void);
void trx_ppc_int_lwz(void);
void trx_ppc_int_lwzu(void);
void trx_ppc_int_lwbrx(void);					
void trx_ppc_int_lbz(void);
void trx_ppc_int_lzbu(void);
void trx_ppc_int_stw(void);
void trx_ppc_int_stwu(void);
void trx_ppc_int_stb(void);
void trx_ppc_int_stbu(void);
void trx_ppc_int_lhz(void);
void trx_ppc_int_lhzu(void);					
void trx_ppc_int_lhbrx(void);					
void trx_ppc_int_lha(void);					
void trx_ppc_int_lhau(void);					
void trx_ppc_int_lhax(void);					
void trx_ppc_int_sth(void);
void trx_ppc_int_sthu(void);
void trx_ppc_int_lmw(void);
void trx_ppc_int_lswi(void);
void trx_ppc_int_stmw(void);
void trx_ppc_int_dcbz(void);
// decoding
void trx_ppc_int_group19(void);
void trx_ppc_int_group31(void);
