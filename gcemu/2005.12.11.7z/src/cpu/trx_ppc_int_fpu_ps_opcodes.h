/*====================================================================

filename:     trx_ppc_int_fpu_ps_opcodes.h
project:      GCemu
created:      2004-6-18
mail:		  duddie@walla.com

Copyright (c) 2005 Duddie & Tratax

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

====================================================================*/
#pragma once

#define FPU_SIGN_BIT (0x8000000000000000ULL)

//fpu
void trx_ppc_int_fresx(void);
void trx_ppc_int_fdivx(void);
void trx_ppc_int_faddx(void);
void trx_ppc_int_fmsubx(void);
void trx_ppc_int_fmaddx(void);
void trx_ppc_int_fnmsubx(void);
void trx_ppc_int_fnmaddx(void);
void trx_ppc_int_fdivsx(void);
void trx_ppc_int_fsubsx(void);
void trx_ppc_int_faddsx(void);
void trx_ppc_int_fmulsx(void);
void trx_ppc_int_fmaddsx(void);
void trx_ppc_int_fmsubsx(void);
void trx_ppc_int_fnmsubsx(void);
void trx_ppc_int_fnmaddsx(void);
void trx_ppc_int_fselx(void);
void trx_ppc_int_fcmpu(void);
void trx_ppc_int_fctiwzx(void);
void trx_ppc_int_fctiwx(void);
void trx_ppc_int_frsqrtex(void);
void trx_ppc_int_fcmpo(void);
void trx_ppc_int_mtfsb1x(void);
void trx_ppc_int_mtfsb0x(void);
void trx_ppc_int_mffsx(void);
void trx_ppc_int_mcrfs(void);
void trx_ppc_int_mtfsfx(void);
void trx_ppc_int_fnegx(void);
void trx_ppc_int_fmrx(void);
void trx_ppc_int_fabsx(void);
void trx_ppc_int_fnabsx(void);
void trx_ppc_int_fsubx(void);
void trx_ppc_int_fmulx(void);
void trx_ppc_int_frspx(void);
void trx_ppc_int_lfs(void);
void trx_ppc_int_lfsu(void);
void trx_ppc_int_lfsx(void);
void trx_ppc_int_lfsux(void);
void trx_ppc_int_lfd(void); 
void trx_ppc_int_lfdu(void); 
void trx_ppc_int_lfdx(void); 
void trx_ppc_int_lfdux(void); 
void trx_ppc_int_stfs(void); 
void trx_ppc_int_stfsu(void);
void trx_ppc_int_stfsx(void);
void trx_ppc_int_stfsux(void);
void trx_ppc_int_stfd(void);
void trx_ppc_int_stfdu(void);
void trx_ppc_int_stfdx(void);
void trx_ppc_int_stfdux(void);
void trx_ppc_int_stfiwx(void);

// decoding
void trx_ppc_int_group59(void);
void trx_ppc_int_group63(void);
void trx_ppc_int_gekko(void);
void trx_ppc_int_dcbz_l(void);
// gekko
void trx_ppc_int_psq_l(void);
void trx_ppc_int_psq_lu(void);
void trx_ppc_int_psq_st(void);
void trx_ppc_int_psq_stu(void);
void trx_ppc_int_psq_lx(void);
void trx_ppc_int_psq_lux(void);
void trx_ppc_int_psq_stx(void);
void trx_ppc_int_psq_stux(void);
void trx_ppc_int_ps_cmpu0(void);
void trx_ppc_int_ps_cmpo0(void);
void trx_ppc_int_ps_cmpu1(void);
void trx_ppc_int_ps_cmpo1(void);
void trx_ppc_int_ps_neg(void);
void trx_ppc_int_ps_mr(void); 
void trx_ppc_int_ps_nabs(void);
void trx_ppc_int_ps_abs(void); 
void trx_ppc_int_ps_sum0(void);
void trx_ppc_int_ps_sum1(void);
void trx_ppc_int_ps_muls0(void);
void trx_ppc_int_ps_muls1(void);
void trx_ppc_int_ps_madds0(void);
void trx_ppc_int_ps_madds1(void);
void trx_ppc_int_ps_merge00(void);
void trx_ppc_int_ps_merge01(void);
void trx_ppc_int_ps_merge10(void);
void trx_ppc_int_ps_merge11(void);
void trx_ppc_int_ps_div(void);
void trx_ppc_int_ps_sub(void);
void trx_ppc_int_ps_add(void);
void trx_ppc_int_ps_sel(void);
void trx_ppc_int_ps_mul(void);
void trx_ppc_int_ps_rsqrte(void);
void trx_ppc_int_ps_msub(void);
void trx_ppc_int_ps_madd(void);
void trx_ppc_int_ps_nmsub(void);
void trx_ppc_int_ps_nmadd(void);
