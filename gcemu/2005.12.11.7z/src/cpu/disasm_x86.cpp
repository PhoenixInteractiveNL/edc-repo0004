/*

  Disassembler ripped from bochs


*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "system/types.h"
#include "cpu/disasm/disasm.h"

static disassembler x86_disassembler;

int disasm_x86(unsigned int addr, char *outputstr)
{
	return x86_disassembler.disasm(1, 0, addr, (uint8 *)addr, outputstr);
}
