#pragma once

// input: -memory address of start of instruction
//        -string with space for up to 256 characters 
// returns size of instruction, and disassembly in given string
int disasm_x86(unsigned int addr, char *outputstr);

