/*====================================================================

filename:     trx_ppc_rec_opcodes.h
project:      GCemu
created:      2004-6-18
mail:		  duddie@walla.com

Copyright (c) 2005 Duddie & Tratax

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

====================================================================*/
#pragma once

void trx_ppc_gen_bclrx(void);
void trx_ppc_gen_mtsr();
void trx_ppc_gen_mtsrin();
void trx_ppc_gen_mfsr();
void trx_ppc_gen_mfsrin();
void trx_ppc_gen_rfi(void);
void trx_ppc_gen_crxor(void);
void trx_ppc_gen_cror(void);
void trx_ppc_gen_crnor(void);
void trx_ppc_gen_crand(void);
void trx_ppc_gen_creqv(void);
void trx_ppc_gen_bcctrx(void);
void trx_ppc_gen_cmp(void);
void trx_ppc_gen_subfcx(void);
void trx_ppc_gen_addcx(void);
void trx_ppc_gen_mulhwux(void);
void trx_ppc_gen_mfcr(void);
void trx_ppc_gen_lwzx(void);
void trx_ppc_gen_lwzux(void);
void trx_ppc_gen_slwx(void);
void trx_ppc_gen_cntlzwx(void);
void trx_ppc_gen_andx(void);
void trx_ppc_gen_nandx(void);
void trx_ppc_gen_cmpl(void);
void trx_ppc_gen_subfx(void);
void trx_ppc_gen_andcx(void);
void trx_ppc_gen_mulhwx(void);
void trx_ppc_gen_mfmsr(void);
void trx_ppc_gen_lbzx(void);
void trx_ppc_gen_lbzux(void);
void trx_ppc_gen_negx(void);
void trx_ppc_gen_norx(void);
void trx_ppc_gen_subfex(void);
void trx_ppc_gen_subfzex(void);
void trx_ppc_gen_addex(void);
void trx_ppc_gen_mtcrf(void);
void trx_ppc_gen_mcrxr(void);
void trx_ppc_gen_mcrf(void);
void trx_ppc_gen_icbc(void);
void trx_ppc_gen_sc(void);
void trx_ppc_gen_mtmsr(void);
void trx_ppc_gen_stwx(void);
void trx_ppc_gen_stfiwx(void);
void trx_ppc_gen_stwux(void);
void trx_ppc_gen_stwbrx(void);
void trx_ppc_gen_addzex(void);
void trx_ppc_gen_addmex(void);
void trx_ppc_gen_stbx(void);
void trx_ppc_gen_stbux(void);
void trx_ppc_gen_mullwx(void);
void trx_ppc_gen_addx(void);
void trx_ppc_gen_lhzx(void);
void trx_ppc_gen_lhzux(void);
void trx_ppc_gen_xorx(void);
void trx_ppc_gen_eqvx(void);
void trx_ppc_gen_mfspr(void);
void trx_ppc_gen_mftb(void);
void trx_ppc_gen_sthx(void);
void trx_ppc_gen_sthux(void);
void trx_ppc_gen_sthbrx(void);
void trx_ppc_gen_orx(void);
void trx_ppc_gen_orcx(void);
void trx_ppc_gen_divwx(void);
void trx_ppc_gen_divwux(void);
void trx_ppc_gen_mtspr(void);
void trx_ppc_gen_divwux(void);
void trx_ppc_gen_srwx(void);
void trx_ppc_gen_srawx(void);
void trx_ppc_gen_srawix(void);
void trx_ppc_gen_extshx(void);
void trx_ppc_gen_extsbx(void);
void trx_ppc_gen_mulli(void);
void trx_ppc_gen_subfic(void);
void trx_ppc_gen_cmpli(void);
void trx_ppc_gen_cmpi(void);
void trx_ppc_gen_addic(void);
void trx_ppc_gen_addic_(void);
void trx_ppc_gen_addi(void);
void trx_ppc_gen_addis(void);
void trx_ppc_gen_bcx(void);
void trx_ppc_gen_bx(void);
void trx_ppc_gen_rlwimix(void);
void trx_ppc_gen_rlwinmx(void);
void trx_ppc_gen_rlwnmx(void);
void trx_ppc_gen_ori(void);
void trx_ppc_gen_oris(void);
void trx_ppc_gen_xori(void);
void trx_ppc_gen_xoris(void);
void trx_ppc_gen_andi_(void);
void trx_ppc_gen_andis_(void);
void trx_ppc_gen_lwz(void);
void trx_ppc_gen_lwzu(void);
void trx_ppc_gen_lwbrx(void);					
void trx_ppc_gen_lbz(void);
void trx_ppc_gen_lzbu(void);
void trx_ppc_gen_stw(void);
void trx_ppc_gen_stwu(void);
void trx_ppc_gen_stb(void);
void trx_ppc_gen_stbu(void);
void trx_ppc_gen_lhz(void);
void trx_ppc_gen_lhzu(void);					
void trx_ppc_gen_lhbrx(void);					
void trx_ppc_gen_lha(void);					
void trx_ppc_gen_lhau(void);					
void trx_ppc_gen_lhax(void);					
void trx_ppc_gen_sth(void);
void trx_ppc_gen_sthu(void);
void trx_ppc_gen_lmw(void);
void trx_ppc_gen_lswi(void);
void trx_ppc_gen_stmw(void);
void trx_ppc_gen_stswi(void);
void trx_ppc_gen_dcbz(void);
// decoding
void trx_ppc_gen_group19(void);
void trx_ppc_gen_group31(void);
// debugging support
void trx_gen_breakpoint(void);
