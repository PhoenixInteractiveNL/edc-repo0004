/*====================================================================

filename:     output.cpp
project:      GCemu
created:      2004-6-18
mail:		  duddie@walla.com

Copyright (c) 2005 Duddie & Tratax

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

====================================================================*/
#if 0

#include "syslog.h"
//#include <stdio.h>

void dbg_osreport(void)
{
	char *str;
	char *out;
	char print[256];
	uint32 pos = 4;
	char *xx = "%s";
	uint32 param;
	
	str = (char *)(gMemory + (gCPU.gpr[3] & 0x3fffffff));
//	puts(str);

	while(*str)
	{
		if (*str == '%')
		{
			out = print;
			*out++ = *str++;
			while(*str < 'A' || *str > 'z' || *str == 'l' || *str == '-')
				*out++ = *str++;
			
			*out++ = *str;
			*out = 0;
			if (pos > 10)
			{
				ppc_read_effective_word(gCPU.gpr[1] + 0x8 + ((pos - 11) * 4), param);
			}
			else
			{
				param = gCPU.gpr[pos];
			}
			pos++;
			//syslog("sp %08x %08x\n", gCPU.gpr[1], param);
			switch(*str)
			{
			case 's':
				syslog(print, (char *)(gMemory + (param & 0x3fffffff)));
				break;
			default:
				syslog(print, param);
				break;
			}
			str++;
		}
		else
		{
			syslog("%c", *str); 
			str++;
		}
	}
}
#endif