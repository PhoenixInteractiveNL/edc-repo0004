#pragma once

void ogl_init_shaders(void);
void ogl_enable_shader(void);
void ogl_disable_shader(void);
