#pragma once
#include "system/types.h"

#define GXOGL_API __declspec(dllexport)

extern uint8 *gx_memory;

typedef struct
{
	void (*gc_pe_set_token)(uint8 n, uint16 token);
} gx_callbacks_t;

extern gx_callbacks_t gx_cbs;
