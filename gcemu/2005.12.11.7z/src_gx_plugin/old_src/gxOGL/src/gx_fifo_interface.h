#pragma once
bool pe_check_interrupt(void);

void gx_write_fifo256(uint8 *data);

void gx_write_fifo8(uint32 data);
void gx_write_fifo16(uint32 data);
void gx_write_fifo32(uint32 data);