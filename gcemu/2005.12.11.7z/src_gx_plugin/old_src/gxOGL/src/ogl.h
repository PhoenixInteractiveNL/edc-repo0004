#pragma once
#include <Windows.h>
#include "system/types.h"

void ogl_init(HWND wnd);
void ogl_info(void);
void ogl_finish_render(void);
