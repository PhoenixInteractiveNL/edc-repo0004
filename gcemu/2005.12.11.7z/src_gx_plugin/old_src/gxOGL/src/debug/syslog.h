#pragma once

#define WITH_LOGGING 1

#if WITH_LOGGING
void syslog(int type, char *fmt,...);
#else
#define syslog ;//
#endif

void syslog_error(int type, char *fmt,...);
void syslog_warn(int type, char *fmt,...);

