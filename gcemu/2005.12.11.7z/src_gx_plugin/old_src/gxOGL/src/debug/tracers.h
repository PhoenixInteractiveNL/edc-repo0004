#pragma once

#include "system/types.h"
#include "debug/syslog.h"

enum LOG_TYPE
{
	MAIN,
	LOAD,
	CPU,
	IO_CORE,
	CMP,
	EXI,
	ARAM,
	DSPI,
	DI,
	SI,
	CP,
	TE,
	MC,
	VI,
	BP,
	VX,
	GX,
	XF,
	WGL,
	LOG_TYPE_MAX
};

char *log_id[];
uint32 log_trace_on[];
