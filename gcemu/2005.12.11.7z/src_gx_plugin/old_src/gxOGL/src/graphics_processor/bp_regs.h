#pragma once

#include "system/types.h"
#include "gp_defs.h"

uint32	gp_bp_regs[];
void gp_bp_write_reg32(uint32 reg, uint32 data);
