#pragma once

void dmsg_init(void);
void dmsg_printf(char *fmt, ...);
