#pragma once

#include "system/types.h"

void fsg_generate(void);
void fsg_init(void);
