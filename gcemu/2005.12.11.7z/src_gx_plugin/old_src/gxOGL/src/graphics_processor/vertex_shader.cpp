#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "system/types.h"

static char vs_shader_source[10*1024];

#define VS_ADD(X)	strcat(vs, X)

#define VS_BEGIN	VS_ADD("{\n")
#define VS_END		VS_ADD("}\n")

void vs_build(uint32 color0ctrl, uint32 invtxspec)
{
	char *vs;

	vs = vs_shader_source;

	sprintf(vs, "void main(");
	VS_ADD("in float4 ipos : POSITION\n");
	VS_ADD("out float4 opos : POSITION\n");
	VS_BEGIN;
	VS_ADD("opos = ipos\n");
	VS_END;
}