#pragma once

void wgl_error(char *str);
