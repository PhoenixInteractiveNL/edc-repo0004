#include "config.h"

#include <windows.h>
#include "wgl_helper.h"
#include "debug/tracers.h"

void wgl_error(char *str)
{                                 
	LPVOID lpMsgBuf;
	int err;

	err = GetLastError();
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | 	FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, err,	MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL );
	syslog_error(WGL,"%s: %x %s\n", str, err, (char *)lpMsgBuf);
}