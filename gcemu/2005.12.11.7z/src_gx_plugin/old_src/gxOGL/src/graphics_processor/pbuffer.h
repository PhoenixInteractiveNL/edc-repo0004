#pragma once


void pb_create_pbuffer(int width, int height);
void pb_select_pbuffer(bool active);
void pb_copy_to_screen(void);


