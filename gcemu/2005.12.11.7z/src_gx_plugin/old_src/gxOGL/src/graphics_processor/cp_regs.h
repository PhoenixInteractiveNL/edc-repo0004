#pragma once

#include "system/types.h"
#include "gp_defs.h"

extern uint32	gp_cp_regs[256];
void gp_cp_write_reg(uint32 reg, uint32 data);
