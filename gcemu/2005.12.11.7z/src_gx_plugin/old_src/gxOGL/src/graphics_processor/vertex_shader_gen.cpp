#include "config.h"

#if WITH_VERTEX_SHADER_GENERATOR

#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <string.h>
#include "system/types.h"

#include "vertex_shader_gen.h"

static char		vsg_program_source[10*1024];
static uint32	vsg_icount;
static uint32	vsg_icount_peak;
static GLuint	vsg_vertex_program;


#define VS_ADD(X)		vsg_icount++;strcat(vs, X);strcat(vs,"\n");
#define VS_ADD_VAR(X)	strcat(vs, X);strcat(vs,"\n");

#define	VS_INIT()	vs[0] = 0
#define VS_HEADER()	VS_ADD("!!ARBvp1.0")
#define	VS_END()	VS_ADD("END");

void vsg_generate_program_source(void)
{
	uint32	i;
	char	*vs;

	vs = vsg_program_source;

	vsg_icount = 0;

	VS_INIT();
	VS_HEADER();

	VS_END();
}


#endif // WITH_VERTEX_SHADER_GENERATOR