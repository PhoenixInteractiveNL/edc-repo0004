#pragma once

#include "system/types.h"

typedef union 
{
	uint32	i;
	float	f;
} gp_reg;


