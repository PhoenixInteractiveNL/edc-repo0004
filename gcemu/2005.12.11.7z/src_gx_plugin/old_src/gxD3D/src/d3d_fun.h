#pragma once

#include <d3d9.h>
#include <Windows.h>

extern IDirect3DDevice9 *g_pd3dDevice;

void d3d_init(void);
void d3d_shutdown(void);
bool d3d_open(HWND wnd);

void d3d_beginscene(void);
void d3d_endscene(void);

void *d3d_create_texture(uint32 fmt, uint32 w, uint32 h, void *bits);
void d3d_delete_texture(void *tex);
void d3d_set_texture(uint32 id, void *tex);

typedef enum
{
	D3D_GC_TF_ARGB8 = 0,
	D3D_GC_TF_I8,
} d3d_tf_t;
