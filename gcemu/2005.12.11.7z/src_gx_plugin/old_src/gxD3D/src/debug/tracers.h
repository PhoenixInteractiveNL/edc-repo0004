#pragma once

#include "system/types.h"
#include "debug/syslog.h"

enum LOG_TYPE
{
	CP,
	BP,
	VX,
	GX,
	XF,
	TE,
	DXX,
	LOG_TYPE_MAX
};

char *log_id[];
uint32 log_trace_on[];
