#pragma once

static inline uint32 byteswap32(uint32 data)
{
	__asm
	{
		mov	eax, data
			bswap eax
	}
}

static inline uint16 byteswap16(uint16 data)
{
	return (data<<8)|(data>>8);
}
