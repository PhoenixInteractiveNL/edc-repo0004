/***************************************************************************
                          cfg.c  -  description
                             -------------------
    begin                : 04.06.2005
    copyright            : (C) 2005 by Pete Bernert
    email                : BlackDove@addcom.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version. See also the license.txt file for *
 *   additional informations.                                              *
 *                                                                         *
 ***************************************************************************/

//*************************************************************************//
// History of changes:
//
// 2005/06/04 - Pete
// - added this small config file handling
//
//*************************************************************************//

#include "stdafx.h"
                                                       
#include <stdio.h>
#include "cfg.h"         
#define _IN_CFG
#include "externals.h"         

/////////////////////////////////////////////////////////

void ReadConfig(void)                                  
{
 FILE *in;char t[256];int len;
 char * pB, * p;

 GetModuleFileName(hInst,t,255);
 p=strrchr(t,'.');
 if(!p) return;

 strcpy(p+1,"CFG");                                    // pluginfilename.CFG
 
 in = fopen(t,"rb"); 
 if(!in) return;

 printf("[GX PLUGIN] using ");                         // some user info
 printf(t);
 printf("\n");

 pB=(char *)malloc(32767);
 memset(pB,0,32767);

 len = fread(pB, 1, 32767, in);                        // now read settings from file
 fclose(in);

 strcpy(t,"\nXSize");p=strstr(pB,t);if(p) {p=strstr(p,"=");len=1;}
 if(p) iResX=atoi(p+len);
 if(iResX<10) iResX=10;

 strcpy(t,"\nYSize");p=strstr(pB,t);if(p) {p=strstr(p,"=");len=1;}
 if(p) iResY=atoi(p+len);
 if(iResY<10) iResY=10;

 strcpy(t,"\nFullScreen");p=strstr(pB,t);if(p) {p=strstr(p,"=");len=1;}
 if(p) iWindowMode=!atoi(p+len);
 if(iWindowMode>1) iWindowMode=1;

 strcpy(t,"\nFBUpload");p=strstr(pB,t);if(p) {p=strstr(p,"=");len=1;}
 if(p) iFBUpload=atoi(p+len);
 if(iFBUpload<0) iFBUpload=0;

 strcpy(t,"\nFogEnable");p=strstr(pB,t);if(p) {p=strstr(p,"=");len=1;}
 if(p) bUseFog=atoi(p+len);

 free(pB);
}

/////////////////////////////////////////////////////////
