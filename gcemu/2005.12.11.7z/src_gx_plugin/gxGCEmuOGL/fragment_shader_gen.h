
void fsg_generate(void);
void fsg_init(void);
