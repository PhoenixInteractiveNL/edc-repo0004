
#define GX_CACHE_BLOCKSHIFT (5)
#define GX_CACHE_BLOCKSIZE (1 << GX_CACHE_BLOCKSHIFT)

int   gx_cache_init(void);
void  gx_cache_snoop(uint32 address);
void  gx_cache_mark_valid(uint32 address, uint32 size);
void  gx_cache_mark_invalid(uint32 address, uint32 size);
uint8 gx_cache_check(uint32 address, uint32 size);

