
void   pe_init(void);
void   pe_close(void);
void   pe_write_register8(uint32 addr, uint8 data);
void   pe_write_register16(uint32 addr, uint16 data);
void   pe_write_register32(uint32 addr, uint32 data);
uint8  pe_read_register8(uint32 addr);
uint16 pe_read_register16(uint32 addr);
uint32 pe_read_register32(uint32 addr);
bool   pe_check_interrupt(void);
