
///////////////////////////////////////////////////////////////////////////

#ifndef _IN_GX

extern uint8 *      gx_memory;
extern gxcb_t       gxcbts[];

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_GXCACHE

extern uint8 *gx_cache_table;

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_GXFIFO

extern int    render_count;

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_PE

extern char  pe_regs[];
extern bool  pe_finished;
extern uint8 pe_irq_enable;

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_VTX_PROC

extern vx_vertex_ptr_t	vx_vertex_ptr;
extern uint8			vx_vertex_data_ub[];
extern uint8		*   vx_vertex_data_size;
extern uint32           vx_started;

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_CPREGS

extern uint32	gp_cp_regs[];

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_XFREGS

extern gp_reg	gp_xf_regs[];
extern GLfloat  xf_texture_matrix[8][16];
extern GLfloat  mat_col[];

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_BPREGS

extern uint32      gp_bp_regs[];
extern uint8       bp_tmem[];
extern uint32      bp_tex_addr;
extern uint32      bp_tlut_addr;
extern uint32      bp_tmem_maddr;
extern uint8       bp_tlut_rgba32[];
extern uint8       tex_tlut_rgba32[];
extern uint32      tx_paletted;
extern bp_efb_info efb_info;
extern uint32      tex_width[];
extern uint32      tex_height[];
extern uint8       tex_fmt[];
extern uint8       bp_fog;
extern bool        bUseFog;

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_OGLGENERIC

extern HINSTANCE hInst;

extern PFNGLMULTITEXCOORD2FARBPROC            glMultiTexCoord2fARB_Ex;
extern PFNGLACTIVETEXTUREARBPROC              glActiveTextureARB_Ex;

extern PFNGLPROGRAMENVPARAMETER4FARBPROC      glProgramEnvParameter4fARB_Ex;
extern PFNGLPROGRAMENVPARAMETER4FVARBPROC     glProgramEnvParameter4fvARB_Ex;

extern PFNGLGENPROGRAMSARBPROC                glGenProgramsARB_Ex;
extern PFNGLDELETEPROGRAMSARBPROC             glDeleteProgramsARB_Ex;
extern PFNGLBINDPROGRAMARBPROC                glBindProgramARB_Ex;
extern PFNGLPROGRAMSTRINGARBPROC              glProgramStringARB_Ex;
extern PFNGLGETPROGRAMIVARBPROC               glGetProgramivARB_Ex;

extern BYTE *         pbTransferBuf;
extern BYTE *         pbTransferBufEx;

extern int            iResX;
extern int            iResY;
extern int            iWindowMode;
extern int            iFBUpload;

#ifdef AUX_ENABLE
void auxprintf (LPCTSTR pFormat, ...);
#endif

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_TEXENV

extern float	    te_reg_col[8][4];
extern bool		    te_modified;
extern uint8	    te_active_stages;
extern uint16	    tev_stage[];
extern uint32	    te_combiner_regs[];
extern uint16	    tev_konst[];
extern uint32	    tev_konst_modified;
extern uint32	    tev_stage_modified;
extern char *       te_kcsel[];
extern char *       te_kasel[];
extern uint8        te_swap_table[4];
extern const char * te_color_inputs[];
extern const char * te_alpha_inputs[];

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_TEXCONV

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_TEXCACHE

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_FSGEN

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_FPS

extern BOOL    bInitCap; 
extern int     iUseFrameLimit;
extern uint32  ulKeybits;

#endif

///////////////////////////////////////////////////////////////////////////

#ifndef _IN_VIDREGS

extern uint32 fb_addr;
extern uint16 fb_vtr;
extern uint16 fb_dcr;
extern uint32 fb_htr0;
extern uint32 fb_htr1;
extern uint16 fb_hsw;
extern uint16 fb_hsr;
extern uint16 fb_prgr;
extern uint32 fb_odd;
extern uint32 fb_even;

#endif

///////////////////////////////////////////////////////////////////////////
