
void gp_cp_write_reg(uint32 reg, uint32 data);
