
void gx_write_fifo8(uint32 data);
void gx_write_fifo16(uint32 data);
void gx_write_fifo32(uint32 data);
void gx_write_fifo(uint8 *data, uint32 len);
