
#define KEY_SHOWFPS 1

void MakeFPSMenu(void);
void KillFPSMenu(void);
void DisplayFPSMenu(void);
void CheckFrameRate(void);
void InitFPS(void);


