
#define	VX_MAX_CMDS	256

//---------------------------------------------//

void   vx_invalidate_cache(uint32 pos);
uint32 vx_prepare_table(uint32 vat);
void   vx_process_commands(void);
void   vx_begin(uint32);
void   vx_end(void);
void   vx_create_shader(void);

//---------------------------------------------//
//internal funcs (prototypes)     

void vx_pos_unknown(uint32 param); 
void vx_pos_n_xy_u8(uint32 param);
void vx_pos_n_xyz_u8(uint32 param);
void vx_pos_n_xy_s8(uint32 param);
void vx_pos_n_xyz_s8(uint32 param);
void vx_pos_n_xy_u16(uint32 param);
void vx_pos_n_xyz_u16(uint32 param);
void vx_pos_n_xy_s16(uint32 param);
void vx_pos_n_xyz_s16(uint32 param);
void vx_pos_n_xy_f32(uint32 param);
void vx_pos_n_xyz_f32(uint32 param);
void vx_pos_i8_xy_s8(uint32 param);
void vx_pos_i8_xyz_s8(uint32 param);
void vx_pos_i8_xyz_u8(uint32 param);
void vx_pos_i8_xy_s16(uint32 param);
void vx_pos_i8_xyz_s16(uint32 param);
void vx_pos_i8_xyz_f32(uint32 param);
void vx_pos_i16_xyz_s8(uint32 param);
void vx_pos_i16_xyz_s16(uint32 param);
void vx_pos_i16_xyz_f32(uint32 param);

void vx_nor_unknown(uint32 param);
void vx_nor_n_nor_s8(uint32 param);
void vx_nor_n_nor_s16(uint32 param);
void vx_nor_n_nor_f32(uint32 param);
void vx_nor_i8_nor_s8(uint32 param);
void vx_nor_i8_nor_s16(uint32 param);
void vx_nor_i8_nor_f32(uint32 param);
void vx_nor_i16_nor_s8(uint32 param);
void vx_nor_i16_nor_s16(uint32 param);
void vx_nor_i16_nor_f32(uint32 param);

void vx_col_unknown(uint32 param);
void vx_col_n_rgb_rgb8(uint32 param);
void vx_col_n_rgba_rgba4(uint32 param);
void vx_col_n_rgba_rgba8(uint32 param);
void vx_col_i16_rgba_rgba8(uint32 param);
void vx_col_i8_rgb_rgb8(uint32 param);
void vx_col_i8_rgba_rgba8(uint32 param);
void vx_col_i8_rgb_rgb565(uint32 param);
void vx_col_i8_rgba_rgba4(uint32 param);
void vx_col_i16_rgb_rgb565(uint32 param);
void vx_col_i16_rgba_rgba4(uint32 param);
void vx_col_i16_rgb_rgb8(uint32 param);

void vx_tex_unknown(uint32 param);
void vx_tex_n_st_s8(uint32 param);
void vx_tex_n_st_u8(uint32 param);
void vx_tex_n_st_s16(uint32 param);
void vx_tex_n_st_u16(uint32 param);
void vx_tex_n_st_f32(uint32 param);
void vx_tex_i8_st_u8(uint32 param);
void vx_tex_i8_st_s8(uint32 param);
void vx_tex_i8_st_s16(uint32 param);
void vx_tex_i8_st_f32(uint32 param);
void vx_tex_i16_st_u16(uint32 param);
void vx_tex_i16_st_s16(uint32 param);
void vx_tex_i16_st_f32(uint32 param);
