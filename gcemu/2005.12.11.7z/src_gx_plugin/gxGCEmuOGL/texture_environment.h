
enum 
{
    TE_CC_CPREV = 0,
    TE_CC_APREV,
    TE_CC_C0,
    TE_CC_A0,
    TE_CC_C1,
    TE_CC_A1,
    TE_CC_C2,
    TE_CC_A2,
    TE_CC_TEXC,
    TE_CC_TEXA,
    TE_CC_RASC,
    TE_CC_RASA,
    TE_CC_ONE,
    TE_CC_HALF,
    TE_CC_KONST,
    TE_CC_ZERO
};

enum
{
    TE_CA_APREV = 0,
    TE_CA_A0,
    TE_CA_A1,
    TE_CA_A2,
    TE_CA_TEXA,
    TE_CA_RASA,
    TE_CA_KONST,
    TE_CA_ZERO
};

enum
{
	CC_ZERO = 0,
	CC_ONE,
	CC_HALF,
	CC_QUARTER,
	CC_REG_PREV,
	CC_REG_C0,
	CC_REG_C1,
	CC_REG_C2,
};

enum
{
	TE_KCSEL_1    = 0x00,
    TE_KCSEL_7_8,
    TE_KCSEL_3_4,
    TE_KCSEL_5_8,
    TE_KCSEL_1_2,
    TE_KCSEL_3_8,
    TE_KCSEL_1_4,
    TE_KCSEL_1_8,
    TE_KCSEL_K0   = 0x0C,
    TE_KCSEL_K1,
    TE_KCSEL_K2,
    TE_KCSEL_K3,
    TE_KCSEL_K0_R,
    TE_KCSEL_K1_R,
    TE_KCSEL_K2_R,
    TE_KCSEL_K3_R,
    TE_KCSEL_K0_G,
    TE_KCSEL_K1_G,
    TE_KCSEL_K2_G,
    TE_KCSEL_K3_G,
    TE_KCSEL_K0_B,
    TE_KCSEL_K1_B,
    TE_KCSEL_K2_B,
    TE_KCSEL_K3_B,
    TE_KCSEL_K0_A,
    TE_KCSEL_K1_A,
    TE_KCSEL_K2_A,
    TE_KCSEL_K3_A
};

enum
{
	TE_KASEL_1    = 0x00,
    TE_KASEL_7_8,
    TE_KASEL_3_4,
    TE_KASEL_5_8,
    TE_KASEL_1_2,
    TE_KASEL_3_8,
    TE_KASEL_1_4,
    TE_KASEL_1_8,
    TE_KASEL_K0_R = 0x10,
    TE_KASEL_K1_R,
    TE_KASEL_K2_R,
    TE_KASEL_K3_R,
    TE_KASEL_K0_G,
    TE_KASEL_K1_G,
    TE_KASEL_K2_G,
    TE_KASEL_K3_G,
    TE_KASEL_K0_B,
    TE_KASEL_K1_B,
    TE_KASEL_K2_B,
    TE_KASEL_K3_B,
    TE_KASEL_K0_A,
    TE_KASEL_K1_A,
    TE_KASEL_K2_A,
    TE_KASEL_K3_A
};

#define TE_COMBINER_REGS_SIZE (sizeof(uint32))

//void te_set_stage(uint32 stage, uint32 color, uint32 alpha);
void te_close(void);
void te_init(void);
void te_set_color_reg_gb(uint32 data, uint8 reg);
void te_set_color_reg_ra(uint32 data, uint8 reg);
