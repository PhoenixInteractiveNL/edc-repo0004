
void bp_init(void);
void gp_bp_write_reg32(uint32 reg, uint32 data);
