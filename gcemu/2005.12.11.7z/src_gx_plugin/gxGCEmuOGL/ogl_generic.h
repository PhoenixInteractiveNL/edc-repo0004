
void ogl_init(HWND wnd);
void ogl_close(void);
void ogl_finish_efb_clear(void);
void ogl_finish_efb_render(void);
void ogl_finish_efb_texture(void);
void ogl_vsync(void);