
void gp_xf_write_reg(uint32 reg, uint32 data);
