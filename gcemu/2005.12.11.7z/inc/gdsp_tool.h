#pragma once

typedef struct gd_globals_t
{
	bool	print_tabs;
	bool	show_hex;
	bool	show_pc;
	bool	decode_names;
	bool	decode_registers;

	uint16	*binbuf;
	uint16	pc;
	char	*buffer;
	uint16	buffer_size;
	char	ext_separator;
} gd_globals_t;




gd_globals_t *gd_init(void);
char *gd_dis_opcode(gd_globals_t *gdg);
uint16 gd_dis_get_opcode_size(gd_globals_t *gdg);
bool gd_dis_file(gd_globals_t *gdg, char *name, FILE *output);
void gd_dis_close_unkop(void);
void gd_dis_open_unkop(void);
void gd_ass_file(gd_globals_t *gdg, char *fname, uint32 pass);
