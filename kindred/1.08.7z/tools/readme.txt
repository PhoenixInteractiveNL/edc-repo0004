ninja.exe will create NINA headers. 

All .nes files will be scanned against a known database.

Run ninja.exe in your rom directory. 

Files are output to a new 'nina' directory.