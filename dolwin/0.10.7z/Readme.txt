    --------------------------------------------------------------------------
    Dolwin 0.10 - Nintendo GAMECUBE Emulator for Windows
    Official Release README, 10 Jan 2005 (by org)
    --------------------------------------------------------------------------

    Dolwin Preface
    --------------

    We are very proud to introduce you new version of Dolwin! 
    Dolwin is the Nintendo GAMECUBE emulator, written by org and hotquik.
    It is able to boot (and run) some commercial games and many home-dev
    demos and applications.

    Features
    --------

    Dolwin can do some high-level emulation of GAMECUBE OS and its based on
    PowerPC interpreter.

    Dolwin is able to compress GCM files.

    Dolwin is integrated with console debugger, which can be used for software
    development and game hacking. It has nice support for breakpoints, patches
    and symbolic information.

    Dolwin is open source emulator, and it has many documentation files for 
    developers and emulator authors. It is written fully on C.

    And as always, Dolwin is faster/compatible, than before :)

    Whats new
    ---------

    Core : 0.10 has totally reanimated core. We rewrote whole interpreter and
    memory core. It is not perfect, but its fine to run some advanced software.

    User Interface : Dolwin has powerful file selector to load GC files. You
    can sort items in many ways, and set file filter for file extensions, 
    which you dont want to add in list. File can be  easily loaded by
    double-clicking on it. Selector will add new search directory itself, after
    succesful loading of supported files (DOL, ELF, GCM or GMP).

    Hardware : Since, we have some HLE in Dolwin, its now high-level emulator,
    but it can work in low-level hardware emulation mode. Dolwin is still able
    to run PONG ;) There are not many changes in hardware emulation, since 0.09.
    We just cleaned whole code, added DVD plugin and memory cards :)

    HLE : Currently Dolwin has some HLE support for Nintendo Dolphin OS. 
    MAP-files are required for high level emulation.
        Dolwin has built-in MAP-maker module, but you shouldnt rely on it, 
    because Dolphin OS has many versions, and MAP-maker can fail to find all 
    needed OS-calls. This release including only Zelda MAP-file. You can try
    to find others on Dolwin site (put new maps into Dolwin Data directory).

    GCM Compression Details
    -----------------------

    Dolwin DVD plugin is supporting GCM compression, based on famous ZLIB
    library. Compression is absolutely safe to use, because it is not modifying
    original DVD data. Compression details are available in source code.

    Dolwin also including GCMCMPR tool, to compress and decompress GCMs.
    This is DOS command line tool, so you may use DOS shell, FAR as example.

    To compress   : GCMCMPR "gcm_file" "gmp_file"
    To decompress : GCMCMPR "gmp_file" "gcm_file"
    (quotes are required for files with long names)

    Compression takes some time, be patient.

    If you dont familiar with DOS tools, just press right mouse button on 
    GCM in Dolwin file selector, and choose "Compress".

    GMP files can be automatically detected by Dolwin selector, as usual GCMs.

    Frontend Features :
    -------------------

    Dolwin can be loaded from command line. It doesn't support any command
    line parameters, just specify file name, which you want to load, in quotes
    or without them (both are valid) :

        Dolwin.exe PONG.dol
        Dolwin.exe "c:\bust a move.gcm"

    Note, that plugin notification messages will be disabled, so emu may not
    work, if your plugins are not configured properly.

    You can associate Dolwin with any GAMECUBE files : DOL, ELF, GCM or GMP
    (emu doesnt associate files itself).

    Contact us :
    ------------

    There are few reasons, when your mail will be deleted. If you want to get
    answers from us :

        � Do not ask FAQs :)
        � Do not ask about DVD image files. We are not warez delivery!
        � Do not send us huge screenshots or dumps. Ask permission first.
        � Do not send any executables (DOL, ELF or EXE).
        � Do not ask why game X not work.
        � Do not ask about next release.

    Our mails :
        org     <kvzorganic@mail.ru>  (Russia)
        hotquik <hotquik@hotmail.com> (US)

    Dolwin homepage : http://dolwin.emulation64.com
    Official message board : http://www.emutalk.net/showthread.php?t=25055

    You can find us, as 'or9' and 'hotquik' at #dolwin channel on EFNet 
    servers in IRC network.

    Greets :
    --------

    We would like to say Thanks to people, who helped us to make Dolwin :

        Costis          gcdev.com and some valuable information;
        Titanik         made GC development possible;
        tmbinc          details of GC bootrom and first working GX demos;
        DesktopMan      nice GC demos;
        groepaz         YAGCD and many other;
        FiRES and ector for Dolphin-emulator, nice chats and information;
        Masken          some ideas from WhineCube;
        monk            some ideas from gcube;
        Alex Raider     basic Windows Console code.

    And also to people, we have forgot or who wanted to stay anonymous :)

    Many thanks to our Beta-testers, for bug and compatibility reports.
    Dolwin Beta-team : Chrono, darkreign, Jeil, Knuckles, MasterPhW and Posty.

    Thanks to Martin for web-hosting on Emulation64.com

    --------------------------------------------------------------------------

    Copyright (C) 2003, 2004. Dolwin Team.
    