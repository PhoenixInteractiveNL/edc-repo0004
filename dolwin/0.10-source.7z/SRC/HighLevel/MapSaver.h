void    SaveMAP(char *mapname="this");
