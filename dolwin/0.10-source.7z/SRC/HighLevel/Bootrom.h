void    BootROM(BOOL dvd);
