extern  DSPMicrocode AXSlave;
