void    con_tokenizing(char *line);
void    con_read_input(int peek);
