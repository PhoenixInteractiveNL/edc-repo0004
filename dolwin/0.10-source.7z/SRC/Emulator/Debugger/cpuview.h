void    con_ldst_info();
void    con_update_disa_window();
void    con_disa_show_compile();
