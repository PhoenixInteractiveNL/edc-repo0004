void    con_memorize_cpu_regs();
void    con_update_registers();
