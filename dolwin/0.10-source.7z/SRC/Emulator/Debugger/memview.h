void    con_update_dump_window();
void    con_memedit();
