char*   dasm86(u8 *ops, int coff, int *len);
