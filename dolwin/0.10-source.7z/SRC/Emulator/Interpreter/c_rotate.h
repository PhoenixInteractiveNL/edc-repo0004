void __fastcall c_RLWINM(u32 op);
void __fastcall c_RLWNM(u32 op);
void __fastcall c_RLWIMI(u32 op);
