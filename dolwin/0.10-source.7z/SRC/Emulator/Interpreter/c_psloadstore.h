void __fastcall c_PSQ_L(u32 op);
void __fastcall c_PSQ_LX(u32 op);
void __fastcall c_PSQ_LU(u32 op);
void __fastcall c_PSQ_LUX(u32 op);
void __fastcall c_PSQ_ST(u32 op);
void __fastcall c_PSQ_STX(u32 op);
void __fastcall c_PSQ_STU(u32 op);
void __fastcall c_PSQ_STUX(u32 op);
