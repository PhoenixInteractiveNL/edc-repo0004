void __fastcall c_BX(u32 op);
void __fastcall c_BCX(u32 op);
void __fastcall c_BCLR(u32 op);
void __fastcall c_BCLRL(u32 op);
void __fastcall c_BCCTR(u32 op);
void __fastcall c_BCCTRL(u32 op);
