void __fastcall c_CMPI(u32 op);
void __fastcall c_CMP(u32 op);
void __fastcall c_CMPLI(u32 op);
void __fastcall c_CMPL(u32 op);
