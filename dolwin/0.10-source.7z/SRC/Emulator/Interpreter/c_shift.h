void __fastcall c_SLW(u32 op);
void __fastcall c_SLWD(u32 op);
void __fastcall c_SRW(u32 op);
void __fastcall c_SRWD(u32 op);
void __fastcall c_SRAWI(u32 op);
void __fastcall c_SRAWID(u32 op);
void __fastcall c_SRAW(u32 op);
void __fastcall c_SRAWD(u32 op);
