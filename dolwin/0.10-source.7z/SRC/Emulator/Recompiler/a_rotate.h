void __fastcall a_RLWINM(u32 op, u32 pc);
void __fastcall a_RLWNM(u32 op, u32 pc);
void __fastcall a_RLWIMI(u32 op, u32 pc);
