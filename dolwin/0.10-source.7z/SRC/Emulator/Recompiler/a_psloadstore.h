void __fastcall a_PSQ_L(u32 op, u32 pc);
void __fastcall a_PSQ_LX(u32 op, u32 pc);
void __fastcall a_PSQ_LU(u32 op, u32 pc);
void __fastcall a_PSQ_LUX(u32 op, u32 pc);
void __fastcall a_PSQ_ST(u32 op, u32 pc);
void __fastcall a_PSQ_STX(u32 op, u32 pc);
void __fastcall a_PSQ_STU(u32 op, u32 pc);
void __fastcall a_PSQ_STUX(u32 op, u32 pc);
