// used for fast type casting and matrix transfers.
