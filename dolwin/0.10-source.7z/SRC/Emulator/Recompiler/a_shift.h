void __fastcall a_SLW(u32 op, u32 pc);
void __fastcall a_SLWD(u32 op, u32 pc);
void __fastcall a_SRW(u32 op, u32 pc);
void __fastcall a_SRWD(u32 op, u32 pc);
void __fastcall a_SRAWI(u32 op, u32 pc);
void __fastcall a_SRAWID(u32 op, u32 pc);
void __fastcall a_SRAW(u32 op, u32 pc);
void __fastcall a_SRAWD(u32 op, u32 pc);
