void __fastcall a_BX(u32 op, u32 pc);
void __fastcall a_BCX(u32 op, u32 pc);
void __fastcall a_BCLR(u32 op, u32 pc);
void __fastcall a_BCLRL(u32 op, u32 pc);
void __fastcall a_BCCTR(u32 op, u32 pc);
void __fastcall a_BCCTRL(u32 op, u32 pc);
