void __fastcall a_CMPI(u32 op, u32 pc);
void __fastcall a_CMP(u32 op, u32 pc);
void __fastcall a_CMPLI(u32 op, u32 pc);
void __fastcall a_CMPL(u32 op, u32 pc);
