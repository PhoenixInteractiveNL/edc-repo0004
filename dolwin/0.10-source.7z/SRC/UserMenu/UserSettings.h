void    ResetAllSettings();
void    OpenSettingsDialog(HWND hParent, HINSTANCE hInst);
void    EditFileInformation(HWND hwnd);
void    EditFileFilter(HWND hwnd);
