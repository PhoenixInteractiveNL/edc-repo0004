void    FontConfigure(HWND hParent);
