void    AboutDialog(HWND hwndParent);
