void    ConfigureGraphicsDialog();
void    ConfigureAudioDialog();
void    ConfigureInputDialog();
void    ConfigureDVDDialog();
void    ConfigureEthernetDialog();
