/*
 * Calls the memcard settings dialog
 */ 
void MemcardConfigure(int num, HWND hParent);
