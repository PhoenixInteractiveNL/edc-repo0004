BOOL    GDIOpen(HWND hwnd, s32 width, s32 height, RGBQUAD **gfxbuf);
void    GDIClose(HWND hwnd);
void    GDIRefresh();
void    GDIResize(s32 width, s32 height);
