// EFB - embedded framebuffer reads (peeks) and writes (pokes)
#include "dolphin.h"

void EFBPeek8(u32 ofs, u32 *reg)
{
}

void EFBPeek16(u32 ofs, u32 *reg)
{
}

void EFBPeek32(u32 ofs, u32 *reg)
{
}

// ---------------------------------------------------------------------------

void EFBPoke8(u32 ofs, u32 data)
{
}

void EFBPoke16(u32 ofs, u32 data)
{
}

void EFBPoke32(u32 ofs, u32 data)
{
}
