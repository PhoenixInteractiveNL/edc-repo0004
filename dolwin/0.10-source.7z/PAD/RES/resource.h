//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by pad.rc
//
#define IDD_DIALOG1                     101
#define IDB_BITMAP1                     102
#define IDB_BITMAP2                     103
#define IDB_BITMAP3                     104
#define IDB_BITMAP4                     105
#define IDB_BITMAP5                     106
#define IDB_BITMAP6                     107
#define IDB_BITMAP7                     108
#define IDB_BITMAP8                     112
#define IDD_DIALOG2                     113
#define IDI_ICON1                       114
#define IDC_BUTTON_X                    1001
#define IDC_BUTTON_START                1002
#define IDC_BUTTON_Y                    1003
#define IDC_BUTTON_A                    1004
#define IDC_BUTTON_B                    1005
#define IDC_BUTTON_RIGHT                1006
#define IDC_BUTTON_DOWN                 1007
#define IDC_BUTTON_LEFT                 1008
#define IDC_BUTTON_UP                   1009
#define IDC_BUTTON_XDOWN50              1010
#define IDC_BUTTON_XDOWN100             1011
#define IDC_BUTTON_XRIGHT50             1012
#define IDC_BUTTON_XRIGHT100            1013
#define IDC_BUTTON_XUP100               1014
#define IDC_BUTTON_XUP50                1015
#define IDC_BUTTON_XLEFT50              1016
#define IDC_BUTTON_XLEFT100             1017
#define IDC_CHECK_PLUG                  1019
#define IDC_BUTTON_CXUP                 1022
#define IDC_BUTTON_CXLEFT               1023
#define IDC_BUTTON_CXDOWN               1024
#define IDC_BUTTON_CXRIGHT              1025
#define IDC_BUTTON_TRIGGERR             1026
#define IDC_BUTTON_TRIGGERL             1027
#define IDC_PAD_CONFIG_OK               1028
#define IDC_PAD_CONFIG_CANCEL           1029
#define IDC_PAD_CONFIG_CLEAR            1030
#define IDC_PAD_ABOUT_OK                1031
#define IDC_BUTTON_TRIGGERZ             1031
#define IDC_ABOUT_STAMP                 1032
#define IDC_PAD_CONFIG_OK2              1032
#define IDC_PAD_CONFIG_CLEAR2           1032
#define IDC_PAD_CONFIG_DEFAULT          1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
