You can put your framefiles in this directory if you wish.

Q: Where do I get framefiles??

A: You make them yourself.  The instructions on how to make them are found in the daphne site
(http://www.daphne-emu.com) in the documentation section.
