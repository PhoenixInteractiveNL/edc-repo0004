DAPHNE v0.99.6c

THE MAIN THING YOU MUST REMEMBER ABOVE ANYTHING ELSE IS :
The daphne_log.txt file is your friend.  If daphne isn't working or if you're
getting errors, _READ_ the daphne_log.txt file!!

NOTE!! This executable sends stats to a central server to create this page:
http://www.daphne-emu.com/stats.html
To prevent daphne from reporting any stats, add -noserversend to the command line.

The documentation is online at http://www.daphne-emu.com/wiki
