This download contains the latest BasiliskII build for Windows, dated the 15th of Janunary 2010.

As the original developer's site is down, all files contained in the original BasiliskII version from the 15th of May 2006 have also been included.

For the BasiliskIIGUI.exe to work, you need to download and install a GTK-runtime environment, available through: http://www.emaculation.com/sheepshaver/gtk+-2.10.13-setup.exe

A setup guide is maintainded at: http://www.emaculation.com/doku.php/basilisk_ii_setup

The file Mac OS ROM allows you to boot and install Mac OS 7.5 through 8.1, while booting from a suitable CD. You can also start Mac OS with the aid of a floppy disk image available here: http://www.emaculation.com/System70_boot.zip