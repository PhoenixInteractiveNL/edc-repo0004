Place VirtualT IDE / Assembler projects within their own
folder in this Projects directory.
