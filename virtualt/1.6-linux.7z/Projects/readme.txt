This folder is a placeholder for projects created from the IDE.
