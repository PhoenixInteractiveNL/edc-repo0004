===========================
VirtualT Developer's Readme
===========================

v0.6
====
Completed support for ReMem emulation in M100/M102 and T200 modes.  Emulation is based on
Rev 4 of the ReMem firmware and also includes support for Rampac emulation in the upper
256K memory range.  Also completed was Rampac emulation, and ReMem + Rampac emulation.
Several fundamental changes were needed to make ReMem work correctly, primarily related
to memory access at the instruction level.  This addition caused about a 20% decrease in
emulation speed, so a separate emulation loop was added for emulation while ReMem is 
enabled.  The application automatically runs / jumps to the correct execution loop when
ReMem is enabled / disabled.

Added code to automatically copy the system ROM and option ROM to default system ReMem
memory space when enabling ReMem so the user doesn't have to manually load the Flash.

Added memory load and save features to the Memory Editor window so users can load ReMem
banks with Option ROMs, etc.


v0.5 (never officially released)
====
Added cpuregs.cpp and cpuregs.h to support CPU Registers Tool.  This tool is the first of
potentially several debug windows.  To support debug, a test was added to the main 
emulation loop to check for active debug windows and call each registered window in 
sequence.  While simple stop/step/run capabilities are included in the window, it is
anticipated that breakpoints, source level debugging, variable access, etc. would be added
using a real "debugger" monitor.  The main loop currently supports up to 3 debug monitor
windows using a simple array.

Updated the T200 ROM with MSPLAN and the rom bank selection code to enable it.


v0.4
====

Several new files have been added to this release to support emulation of multiple models,
the new Memory Editor, and ReMem memory emulation.  The project files and makefiles have
been updated to include the new files as part of the build.  To support the growing number
of source files, the GNUmakefile has been modified significantly.  The makefile was tested
using an older release of Redhat Linux, but should work for any Linux.  Please report any
problems with the new makefile.

The build files (.dsp and GNUmakefile) now require the "FLTKDIR" environment variable to
be set prior to building.  This environment variable must point to the top level directory
where the FLTK libraries have been installed.  The build files use this variable to 
determine where to find include and library files.

Since release v0.4 adds support for emulating multiple models, a directory structure has
abeen established.  The source files now reside in the "src" subdirectory.  On Linux 
platforms, the compiled object files are located in the "obj" subdirectory.  Windows
platforms still compile to the "Debug" and/or "Release" subfolders as always.  The other
folders contain information specific to each emulation model, such as ROM images, RAM 
images, etc.

This release adds initial support for the Help system.  This support is currently limited
to providing a help browser from the "Help" menu item with a single help.htm file.  The
help.htm file is basically empty, except to show the name of the program and a note that
help is forthcoming.

   ANY ASSISTANCE GENERATING A HELP SYSTEM IS WELCOME :)  (hint hint)

I will gladly add any and all changes to the help system to SourceForge and/or add 
anyone who wishes to contribute to the developer list.



Happy Building.  Any questions or issues, simply let me know via SourceForge.net or the
m100 mailing list.

Ken Pettit

