SheepShaver 2.3 - snapshot 2006/05/14

Very Quick Start and Notes

- Get an SDL runtime library:
  <http://www.libsdl.org/download-1.2.php>

- Get a GTK2 runtime library for the GUI:
  <http://gladewin32.sourceforge.net/>

- SheepShaver Help Centre with installation guides:
  <http://www.gibix.net/projects/sheepshaver/>

- SheepShaver will boot off the CD if there is no bootable disk image found.

- You need a NewWorld ROM to take benefit of AltiVec emulation
  as there was no PowerMac PCI ROM supporting G4 processor.

Known bugs and caveats

- Graphics performance is currently suboptimal compared to the
  Linux/X11 version where it is up to 4 times faster.

- NewWorld ROMs can only support Macos 8.5 and upwards.

Links

- Official SheepShaver Homepage:
  <http://sheepshaver.cebix.net/>

- Snapshots and precompiled binaries:
  <http://www.gibix.net/projects/sheepshaver/>

-- 
Gwenole Beauchesne,
<gb.public@free.fr>